<?php
session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    header('Location: login.php');
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'secuscan_db');
if ($conn->connect_error) die('Database connection failed: ' . $conn->connect_error);
$conn->set_charset('utf8mb4');
$admin_page = $_GET['page'] ?? 'monitoring';
$allowed_admin_pages = ['monitoring', 'complaints', 'users', 'reports', 'url-history', 'file-history', 'hash-history', 'ip-history'];
if (!in_array($admin_page, $allowed_admin_pages, true)) $admin_page = 'monitoring';

if (isset($_POST['user_action'])) {
    $target_user_id = (int) ($_POST['user_id'] ?? 0);
    $user_action = (string) $_POST['user_action'];

    if ($target_user_id > 0 && in_array($user_action, ['delete', 'verified', 'not_verified'], true)) {
        if ($user_action === 'delete') {
            $stmt = $conn->prepare('DELETE FROM users WHERE id = ? AND is_admin = 0');
        } else {
            $verified = $user_action === 'verified' ? 1 : 0;
            $stmt = $conn->prepare('UPDATE users SET email_verified = ?, verification_token = ? WHERE id = ? AND is_admin = 0');
            $verification_token = $verified ? null : bin2hex(random_bytes(32));
            $stmt->bind_param('isi', $verified, $verification_token, $target_user_id);
        }
        if ($user_action === 'delete') $stmt->bind_param('i', $target_user_id);
        $stmt->execute();
        $stmt->close();
    }

    header('Location: admin.php?page=users');
    exit();
}

if (isset($_POST['update_complaint_status'])) {
    $complaint_id = (int) ($_POST['complaint_id'] ?? 0);
    $status = $_POST['status'] ?? 'New';
    if ($complaint_id > 0 && in_array($status, ['New', 'In Progress', 'Resolved'], true)) {
        $stmt = $conn->prepare('UPDATE complaints SET status = ? WHERE id = ?');
        $stmt->bind_param('si', $status, $complaint_id);
        $stmt->execute();
        $stmt->close();
    }
    header('Location: admin.php?page=monitoring');
    exit();
}

$users = $conn->query("SELECT * FROM users WHERE is_admin = 0 ORDER BY username");
$complaints = $conn->query("SELECT c.*, u.username FROM complaints c LEFT JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC");
$all_url_logs = $conn->query("SELECT s.*, u.username FROM scan_logs s LEFT JOIN users u ON s.user_id = u.id ORDER BY s.id DESC LIMIT 50");
$all_file_logs = $conn->query("SELECT f.*, u.username FROM file_scan_logs f LEFT JOIN users u ON f.user_id = u.id ORDER BY f.id DESC LIMIT 50");
$all_hash_logs = $conn->query("SELECT h.*, u.username FROM hash_scan_logs h LEFT JOIN users u ON h.user_id = u.id ORDER BY h.id DESC LIMIT 50");
$all_ip_logs = $conn->query("SELECT i.*, u.username FROM ip_scan_logs i LEFT JOIN users u ON i.user_id = u.id ORDER BY i.id DESC LIMIT 50");
$report_period = ($_GET['period'] ?? 'week') === 'month' ? 'month' : 'week';
$report_date_input = $_GET['date'] ?? date('Y-m-d');
$report_date = DateTime::createFromFormat('!Y-m-d', $report_date_input);
if (!$report_date || $report_date->format('Y-m-d') !== $report_date_input) $report_date = new DateTime('today');
$report_start_input = $_GET['start_date'] ?? '';
$report_end_input = $_GET['end_date'] ?? '';
$report_start = DateTime::createFromFormat('!Y-m-d', $report_start_input);
$report_end = DateTime::createFromFormat('!Y-m-d', $report_end_input);
if (!$report_start || $report_start->format('Y-m-d') !== $report_start_input || !$report_end || $report_end->format('Y-m-d') !== $report_end_input) {
    if ($report_period === 'week') {
        $report_start = (clone $report_date)->modify('monday this week');
        $report_end = (clone $report_start)->modify('+6 days');
    } else {
        $report_start = (clone $report_date)->modify('first day of this month');
        $report_end = (clone $report_start)->modify('last day of this month');
    }
} elseif ($report_end < $report_start) {
    $report_end = clone $report_start;
}
$report_start_input = $report_start->format('Y-m-d');
$report_end_input = $report_end->format('Y-m-d');
$report_start_value = $report_start->format('Y-m-d 00:00:00');
$report_end_value = $report_end->format('Y-m-d 23:59:59');
$report_logs = null;
$report_rows = [];
$report_type_counts = ['URL' => 0, 'FILE' => 0, 'HASH' => 0, 'IP' => 0];
if ($admin_page === 'reports') {
    $report_sql = "SELECT scan_type, username, item, result, accuracy, scanned_at FROM (
        SELECT 'URL' AS scan_type, u.username, s.url AS item, s.hasil_pemeriksaan AS result, s.tahap_ketepatan AS accuracy, s.tarikh_semak AS scanned_at FROM scan_logs s LEFT JOIN users u ON s.user_id = u.id
        UNION ALL
        SELECT 'FILE', u.username, f.filename, f.hasil_pemeriksaan, f.tahap_ketepatan, f.tarikh_semak FROM file_scan_logs f LEFT JOIN users u ON f.user_id = u.id
        UNION ALL
        SELECT 'HASH', u.username, COALESCE(h.filename, h.file_hash), h.verdict, NULL, h.scanned_at FROM hash_scan_logs h LEFT JOIN users u ON h.user_id = u.id
        UNION ALL
        SELECT 'IP', u.username, i.ip_address, i.verdict, NULL, i.scanned_at FROM ip_scan_logs i LEFT JOIN users u ON i.user_id = u.id
    ) AS combined_logs WHERE scanned_at BETWEEN ? AND ? ORDER BY scanned_at DESC";
    $report_stmt = $conn->prepare($report_sql);
    $report_stmt->bind_param('ss', $report_start_value, $report_end_value);
    $report_stmt->execute();
    $report_logs = $report_stmt->get_result();
    while ($report_row = $report_logs->fetch_assoc()) {
        $report_rows[] = $report_row;
        if (isset($report_type_counts[$report_row['scan_type']])) $report_type_counts[$report_row['scan_type']]++;
    }
}
$total_users = (int) ($conn->query("SELECT COUNT(*) AS total FROM users WHERE is_admin = 0")->fetch_assoc()['total'] ?? 0);
$total_url = (int) ($conn->query('SELECT COUNT(*) AS total FROM scan_logs')->fetch_assoc()['total'] ?? 0);
$total_file = (int) ($conn->query('SELECT COUNT(*) AS total FROM file_scan_logs')->fetch_assoc()['total'] ?? 0);
$total_hash = (int) ($conn->query('SELECT COUNT(*) AS total FROM hash_scan_logs')->fetch_assoc()['total'] ?? 0);
$total_ip = (int) ($conn->query('SELECT COUNT(*) AS total FROM ip_scan_logs')->fetch_assoc()['total'] ?? 0);
$new_complaints = (int) ($conn->query("SELECT COUNT(*) AS total FROM complaints WHERE status = 'New'")->fetch_assoc()['total'] ?? 0);
$total_complaints = (int) ($conn->query('SELECT COUNT(*) AS total FROM complaints')->fetch_assoc()['total'] ?? 0);
$purpose_counts = ['Education' => 0, 'Work' => 0, 'Others' => 0, 'Shopping' => 0];
$purpose_url_result = $conn->query("SELECT CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END AS purpose, COUNT(*) AS total FROM scan_logs GROUP BY CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END");
$purpose_file_result = $conn->query("SELECT CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END AS purpose, COUNT(*) AS total FROM file_scan_logs GROUP BY CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END");
$purpose_hash_result = $conn->query("SELECT CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END AS purpose, COUNT(*) AS total FROM hash_scan_logs GROUP BY CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END");
$purpose_ip_result = $conn->query("SELECT CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END AS purpose, COUNT(*) AS total FROM ip_scan_logs GROUP BY CASE COALESCE(tujuan, 'Others') WHEN 'Personal' THEN 'Others' WHEN 'Testing' THEN 'Shopping' ELSE COALESCE(tujuan, 'Others') END");
foreach ([$purpose_url_result, $purpose_file_result, $purpose_hash_result, $purpose_ip_result] as $purpose_result) {
    if ($purpose_result) {
        while ($purpose_row = $purpose_result->fetch_assoc()) {
            $purpose_name = $purpose_row['purpose'];
            if (isset($purpose_counts[$purpose_name])) $purpose_counts[$purpose_name] += (int) $purpose_row['total'];
        }
    }
}
$purpose_total = array_sum($purpose_counts);
function e($value) { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
function result_badge_class($value) {
    $result = strtolower(trim((string) $value));
    if (preg_match('/malicious|phishing|malware|danger|unsafe/', $result)) return 'text-bg-danger';
    if (strpos($result, 'suspicious') !== false) return 'text-bg-warning';
    if (preg_match('/safe|clean/', $result)) return 'text-bg-success';
    return 'text-bg-secondary';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SecuScan Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
    <link href="style.css" rel="stylesheet">
    <style>
        :root { --navy:#111827; --blue:#2563eb; --bg:#f4f6fa; }
        body { background:var(--bg); color:#182235; }
        .admin-layout { min-height:100vh; display:flex; }
        .admin-sidebar { width:250px; background:var(--navy); color:#fff; padding:28px 18px; position:fixed; inset:0 auto 0 0; z-index:10; }
        .admin-brand { color:#fff; font-size:1.25rem; font-weight:800; text-decoration:none; display:block; padding:0 12px 35px; }
        .admin-brand i { color:#60a5fa; }
        .admin-label { color:#8491a7; font-size:.68rem; font-weight:800; letter-spacing:.12em; text-transform:uppercase; padding:0 12px; margin:18px 0 8px; }
        .admin-link { display:flex; gap:12px; align-items:center; color:#aeb9c9; text-decoration:none; padding:12px; border-radius:10px; font-weight:600; font-size:.88rem; }
        .admin-link:hover, .admin-link.active { color:#fff; background:#26344d; }
        .admin-link i { width:18px; text-align:center; }
        .admin-main { margin-left:250px; width:calc(100% - 250px); padding:30px 40px 50px; }
        .topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:28px; }
        .eyebrow { color:var(--blue); font-size:.72rem; font-weight:800; letter-spacing:.12em; text-transform:uppercase; }
        .page-title { font-weight:800; letter-spacing:-.04em; margin:4px 0; }
        .panel-card, .metric-card { background:#fff; border:1px solid #e4eaf2; border-radius:16px; box-shadow:0 8px 24px rgba(25,45,75,.05); }
        .metric-card { padding:20px; height:100%; }.metric-icon { width:42px; height:42px; display:grid; place-items:center; border-radius:12px; background:#eff5ff; color:var(--blue); }.metric-value { font-size:1.8rem; font-weight:800; margin-top:12px; }
        .table th { color:#8793a5; font-size:.7rem; text-transform:uppercase; letter-spacing:.06em; white-space:nowrap; }.table td { vertical-align:middle; font-size:.85rem; }.code-font { font-family:monospace; font-size:.78rem; }.complaint-message { white-space:pre-wrap; max-width:290px; color:#607086; }
        .report-heading { background:#f8fbff; }
        .report-brand { display:flex; align-items:center; gap:12px; color:#0f172a; }.report-brand-icon { display:grid; place-items:center; width:42px; height:42px; border-radius:12px; color:#fff; background:linear-gradient(135deg,#2563eb,#1d4ed8); font-size:1.25rem; }.report-brand-name { font-weight:800; font-size:1.1rem; letter-spacing:-.03em; }.report-brand-subtitle { color:#64748b; font-size:.72rem; }.report-summary { display:grid; grid-template-columns:repeat(5,1fr); gap:10px; margin-bottom:16px; }.report-summary-item { border:1px solid #dbe5f2; border-radius:10px; padding:10px 12px; background:#fff; }.report-summary-item strong { display:block; color:#0f172a; font-size:1.1rem; }.report-summary-item small { color:#64748b; font-size:.68rem; text-transform:uppercase; letter-spacing:.06em; }.report-footer { color:#64748b; font-size:.7rem; border-top:1px solid #e2e8f0; margin-top:18px; padding-top:10px; display:flex; justify-content:space-between; }
        @media print {
            @page { size: landscape; margin: 12mm; }
            body { background:#fff !important; }
            .admin-sidebar, .topbar, .report-controls { display:none !important; }
            .admin-main { margin-left:0; width:100%; padding:0; }
            .panel-card { border:0; box-shadow:none; padding:0 !important; }
            .report-heading { border-color:#cbd5e1 !important; background:#fff; }
            .report-page { display:block !important; }
            .report-brand-icon { print-color-adjust:exact; -webkit-print-color-adjust:exact; }
            .report-summary { grid-template-columns:repeat(5,1fr); }
            .report-summary-item { print-color-adjust:exact; -webkit-print-color-adjust:exact; }
            .report-footer { margin-top:14px; }
            .table { font-size:10pt; }
            .table td, .table th { padding:6px; }
        }
        @media(max-width:850px){.admin-sidebar{width:72px;padding:20px 9px}.admin-brand{font-size:0;text-align:center;padding:0 0 25px}.admin-brand i{font-size:1.4rem}.admin-label,.admin-link span{display:none}.admin-link{justify-content:center}.admin-main{margin-left:72px;width:calc(100% - 72px);padding:22px 16px}.topbar{align-items:flex-start;gap:12px}}
        body { background:linear-gradient(135deg,#f8fbff 0%,#eef4ff 45%,#f1f5f9 100%); color:#0f172a; }
        .admin-sidebar { background:rgba(255,255,255,.9); border-right:1px solid rgba(148,163,184,.2); box-shadow:12px 0 28px rgba(15,23,42,.06); }
        .admin-brand { color:#0f172a; text-shadow:none; }.admin-brand i{color:#2563eb}.admin-label{color:#64748b}.admin-link{color:#475569}.admin-link:hover,.admin-link.active{color:#0f172a;background:rgba(96,165,250,.08);box-shadow:inset 3px 0 #60a5fa,0 0 14px rgba(37,99,235,.05)}
        .eyebrow{color:#2563eb}.page-title{color:#0f172a;text-shadow:none}.panel-card,.metric-card{background:rgba(255,255,255,.96);border-color:#e2e8f0;box-shadow:0 18px 42px rgba(15,23,42,.06),inset 0 1px rgba(255,255,255,.9)}.panel-card:hover,.metric-card:hover{border-color:rgba(96,165,250,.28);box-shadow:0 22px 48px rgba(30,41,59,.08),0 0 16px rgba(96,165,250,.08)}.metric-icon{background:rgba(37,99,235,.08);box-shadow:none}.metric-value{color:#0f172a}.text-muted{color:#64748b!important}.table{--bs-table-color:#334155;--bs-table-hover-color:#0f172a;--bs-table-hover-bg:rgba(59,130,246,.04);--bs-table-bg:transparent}.table th{color:#64748b;border-bottom-color:rgba(148,163,184,.2)}.table td{border-bottom-color:rgba(148,163,184,.18)}.form-control,.form-select{background:#fff;color:#0f172a;border-color:#cbd5e1}.form-select option{background:#fff}.btn-outline-primary{color:#2563eb;border-color:#93c5fd}.btn-outline-primary:hover{color:#fff;background:#2563eb}
    </style>
</head>
<body>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <a class="admin-brand" href="admin.php"><i class="fa-solid fa-shield-halved me-2"></i>SecuScan Admin</a>
        <div class="admin-label">Monitoring</div>
        <a class="admin-link <?php echo $admin_page === 'monitoring' ? 'active' : ''; ?>" href="admin.php?page=monitoring"><i class="fa-solid fa-chart-line"></i><span>Monitoring</span></a>
        <a class="admin-link <?php echo $admin_page === 'complaints' ? 'active' : ''; ?>" href="admin.php?page=complaints"><i class="fa-solid fa-inbox"></i><span>User Complaints</span></a>
        <a class="admin-link <?php echo $admin_page === 'users' ? 'active' : ''; ?>" href="admin.php?page=users"><i class="fa-solid fa-users"></i><span>User Directory</span></a>
        <a class="admin-link <?php echo $admin_page === 'reports' ? 'active' : ''; ?>" href="admin.php?page=reports&period=week"><i class="fa-solid fa-file-lines"></i><span>Reports</span></a>
        <div class="admin-label">History</div>
        <a class="admin-link <?php echo $admin_page === 'url-history' ? 'active' : ''; ?>" href="admin.php?page=url-history"><i class="fa-solid fa-link"></i><span>URL Scan History</span></a>
        <a class="admin-link <?php echo $admin_page === 'file-history' ? 'active' : ''; ?>" href="admin.php?page=file-history"><i class="fa-solid fa-file-shield"></i><span>File Scan History</span></a>
        <a class="admin-link <?php echo $admin_page === 'hash-history' ? 'active' : ''; ?>" href="admin.php?page=hash-history"><i class="fa-solid fa-fingerprint"></i><span>Hash Scan History</span></a>
        <a class="admin-link <?php echo $admin_page === 'ip-history' ? 'active' : ''; ?>" href="admin.php?page=ip-history"><i class="fa-solid fa-globe"></i><span>IP Scan History</span></a>
        <div class="admin-label">Account</div>
        <a class="admin-link" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i><span>Log out</span></a>
    </aside>

    <main class="admin-main">
        <header class="topbar"><div><div class="eyebrow">Administrator workspace</div><h1 class="page-title"><?php echo e(ucwords(str_replace('-', ' ', $admin_page))); ?></h1><small class="text-muted">Monitor user security and manage SecuScan complaints.</small></div><span class="badge text-bg-dark rounded-pill px-3 py-2"><i class="fa-solid fa-user-shield me-1"></i> Administrator</span></header>

        <?php if ($admin_page === 'monitoring'): ?>
        <section id="overview" class="row g-3 mb-4">
            <div class="col-sm-6 col-xl-2"><div class="metric-card"><div class="d-flex justify-content-between"><small class="text-muted fw-bold">USERS</small><span class="metric-icon"><i class="fa-solid fa-users"></i></span></div><div class="metric-value"><?php echo $total_users; ?></div></div></div>
            <div class="col-sm-6 col-xl-2"><div class="metric-card"><div class="d-flex justify-content-between"><small class="text-muted fw-bold">URL SCANS</small><span class="metric-icon"><i class="fa-solid fa-link"></i></span></div><div class="metric-value"><?php echo $total_url; ?></div></div></div>
            <div class="col-sm-6 col-xl-2"><div class="metric-card"><div class="d-flex justify-content-between"><small class="text-muted fw-bold">FILE SCANS</small><span class="metric-icon"><i class="fa-solid fa-file-shield"></i></span></div><div class="metric-value"><?php echo $total_file; ?></div></div></div>
            <div class="col-sm-6 col-xl-2"><div class="metric-card"><div class="d-flex justify-content-between"><small class="text-muted fw-bold">HASH SCANS</small><span class="metric-icon"><i class="fa-solid fa-fingerprint"></i></span></div><div class="metric-value"><?php echo $total_hash; ?></div></div></div>
            <div class="col-sm-6 col-xl-2"><div class="metric-card"><div class="d-flex justify-content-between"><small class="text-muted fw-bold">IP SCANS</small><span class="metric-icon"><i class="fa-solid fa-globe"></i></span></div><div class="metric-value"><?php echo $total_ip; ?></div></div></div>
            <div class="col-sm-6 col-xl-2"><div class="metric-card"><div class="d-flex justify-content-between"><small class="text-muted fw-bold">NEW COMPLAINTS</small><span class="metric-icon text-danger bg-danger-subtle"><i class="fa-solid fa-bell"></i></span></div><div class="metric-value text-danger"><?php echo $new_complaints; ?></div></div></div>
        </section>
        <?php endif; ?>

        <?php if ($admin_page === 'monitoring'): ?>
        <section class="row g-4 mb-5">
            <div class="col-lg-7"><div class="panel-card p-4 h-100"><div class="d-flex justify-content-between align-items-center mb-3"><div><h4 class="fw-bold mb-1"><i class="fa-solid fa-chart-pie text-primary me-2"></i>Admin Purpose Analytics</h4><small class="text-muted">Why users run SecuScan scans.</small></div><span class="badge text-bg-primary rounded-pill"><?php echo $purpose_total; ?> scans</span></div><div style="height:280px"><canvas id="purposeChart"></canvas></div></div></div>
            <div class="col-lg-5"><div class="panel-card p-4 h-100"><h5 class="fw-bold mb-3">Purpose Breakdown</h5><?php foreach ($purpose_counts as $purpose_name => $purpose_count): $purpose_percentage = $purpose_total > 0 ? round($purpose_count / $purpose_total * 100, 1) : 0; ?><div class="d-flex justify-content-between align-items-center border-bottom py-3"><span><?php echo e($purpose_name); ?></span><strong><?php echo $purpose_percentage; ?>% <small class="text-muted fw-normal">(<?php echo $purpose_count; ?>)</small></strong></div><?php endforeach; ?><small class="text-muted d-block mt-3">Data combines URL and file scans.</small></div></div>
        </section>
        <script>
            new Chart(document.getElementById('purposeChart'), {
                type: 'doughnut',
                data: { labels: <?php echo json_encode(array_keys($purpose_counts)); ?>, datasets: [{ data: <?php echo json_encode(array_values($purpose_counts)); ?>, backgroundColor: ['#2563eb', '#f59e0b', '#10b981', '#8b5cf6'], borderWidth: 0 }] },
                options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
            });
        </script>
        <?php endif; ?>

        <?php if ($admin_page === 'complaints'): ?>
        <section id="complaints" class="panel-card p-4 mb-5">
            <div class="d-flex justify-content-between align-items-center mb-3"><div><h4 class="fw-bold mb-1"><i class="fa-solid fa-inbox text-primary me-2"></i>User Complaints</h4><small class="text-muted">Total complaints: <?php echo $total_complaints; ?></small></div><span class="badge text-bg-danger rounded-pill"><?php echo $new_complaints; ?> new</span></div>
            <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>User</th><th>Category</th><th>Message</th><th>Status</th><th>Date</th></tr></thead><tbody>
            <?php if ($complaints && $complaints->num_rows > 0): while ($complaint = $complaints->fetch_assoc()): ?><tr><td><strong><?php echo e($complaint['name']); ?></strong><small class="d-block text-muted"><?php echo e($complaint['email']); ?></small></td><td><?php echo e($complaint['category']); ?></td><td class="complaint-message"><?php echo e($complaint['message']); ?></td><td><form method="post" class="d-flex gap-1"><input type="hidden" name="complaint_id" value="<?php echo (int) $complaint['id']; ?>"><select name="status" class="form-select form-select-sm"><option <?php echo $complaint['status'] === 'New' ? 'selected' : ''; ?>>New</option><option <?php echo $complaint['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option><option <?php echo $complaint['status'] === 'Resolved' ? 'selected' : ''; ?>>Resolved</option></select><button name="update_complaint_status" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-check"></i></button></form></td><td><small class="text-muted"><?php echo e($complaint['created_at']); ?></small></td></tr><?php endwhile; else: ?><tr><td colspan="5" class="text-center text-muted py-4">No user complaints found.</td></tr><?php endif; ?>
            </tbody></table></div>
        </section>

        <?php endif; ?>

        <?php if ($admin_page === 'users'): ?>
        <h4 id="users" class="fw-bold mb-3">User Directory</h4>
        <div class="panel-card p-4 mb-5">
            <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Username</th><th>Email</th><th>Verification</th><th>Account Created</th><th>Actions</th></tr></thead><tbody>
            <?php if ($users && $users->num_rows > 0): while ($user = $users->fetch_assoc()): $is_verified = (int) ($user['email_verified'] ?? 0) === 1; ?><tr><td><strong><i class="fa-solid fa-user text-primary me-2"></i><?php echo e($user['username']); ?></strong></td><td><?php echo e($user['email']); ?></td><td><div class="d-flex align-items-center gap-2"><span class="badge <?php echo $is_verified ? 'text-bg-success' : 'text-bg-secondary'; ?> rounded-pill"><?php echo $is_verified ? 'Verified' : 'Not verified'; ?></span><form method="post" class="d-inline"><input type="hidden" name="user_id" value="<?php echo (int) $user['id']; ?>"><button class="btn btn-sm <?php echo $is_verified ? 'btn-outline-secondary' : 'btn-outline-success'; ?>" name="user_action" value="<?php echo $is_verified ? 'not_verified' : 'verified'; ?>"><?php echo $is_verified ? 'Unverify' : 'Verify'; ?></button></form></div></td><td class="text-muted"><small><?php echo e($user['created_at']); ?></small></td><td><form method="post"><input type="hidden" name="user_id" value="<?php echo (int) $user['id']; ?>"><button class="btn btn-sm btn-outline-danger" name="user_action" value="delete" onclick="return confirm('Delete this user account?');"><i class="fa-solid fa-trash me-1"></i>Delete</button></form></td></tr><?php endwhile; else: ?><tr><td colspan="5" class="text-center text-muted py-4">No registered users found.</td></tr><?php endif; ?>
            </tbody></table></div>
        </div>
        <?php endif; ?>

        <?php if ($admin_page === 'reports'): ?>
        <section class="panel-card p-4 mb-5 report-page">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4 report-controls">
                <div><h4 class="fw-bold mb-1"><i class="fa-solid fa-file-lines text-primary me-2"></i>Scan Reports</h4><small class="text-muted">Print a user scan history report by week or month.</small></div>
                <button type="button" class="btn btn-primary" onclick="window.print()"><i class="fa-solid fa-print me-2"></i>Print / Save PDF</button>
            </div>
            <div class="d-flex flex-wrap gap-2 align-items-end mb-4 report-controls">
                <div><label class="form-label small fw-bold mb-1">Report period</label><div class="btn-group" role="group"><a class="btn <?php echo $report_period === 'week' ? 'btn-primary' : 'btn-outline-primary'; ?>" href="admin.php?page=reports&period=week&date=<?php echo e($report_date->format('Y-m-d')); ?>">Week</a><a class="btn <?php echo $report_period === 'month' ? 'btn-primary' : 'btn-outline-primary'; ?>" href="admin.php?page=reports&period=month&date=<?php echo e($report_date->format('Y-m-d')); ?>">Month</a></div></div>
                <form method="get" class="d-flex flex-wrap gap-2 align-items-end"><input type="hidden" name="page" value="reports"><input type="hidden" name="period" value="<?php echo e($report_period); ?>"><div><label class="form-label small fw-bold mb-1">Start date</label><input type="date" name="start_date" class="form-control" value="<?php echo e($report_start_input); ?>" required></div><div><label class="form-label small fw-bold mb-1">End date</label><input type="date" name="end_date" class="form-control" value="<?php echo e($report_end_input); ?>" required></div><button class="btn btn-outline-primary">View report</button></form>
            </div>
            <div class="report-brand mb-3"><span class="report-brand-icon"><i class="fa-solid fa-shield-halved"></i></span><div><div class="report-brand-name">SecuScan</div><div class="report-brand-subtitle">Administrator Security Report</div></div></div>
            <div class="report-heading border rounded-3 p-3 mb-3"><div><strong>SecuScan User Scan History</strong><small class="d-block text-muted">Date range: <?php echo e($report_start->format('d M Y')); ?> - <?php echo e($report_end->format('d M Y')); ?></small></div><span class="badge text-bg-primary rounded-pill"><?php echo count($report_rows); ?> records</span></div>
            <div class="report-summary"><div class="report-summary-item"><strong><?php echo count($report_rows); ?></strong><small>Total scans</small></div><?php foreach ($report_type_counts as $report_type => $report_count): ?><div class="report-summary-item"><strong><?php echo $report_count; ?></strong><small><?php echo e($report_type); ?> scans</small></div><?php endforeach; ?></div>
            <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>No.</th><th>User</th><th>Scan Type</th><th>Scanned Item</th><th>Result</th><th>Accuracy</th><th>Date &amp; Time</th></tr></thead><tbody>
            <?php if (count($report_rows) > 0): $report_number = 1; foreach ($report_rows as $row): ?><tr><td><?php echo $report_number++; ?></td><td><?php echo e($row['username'] ?: 'Guest'); ?></td><td><span class="badge text-bg-light border"><?php echo e($row['scan_type']); ?></span></td><td class="code-font text-break" style="max-width:380px"><?php echo e($row['item']); ?></td><td><span class="badge <?php echo result_badge_class($row['result']); ?> rounded-pill"><?php echo e($row['result']); ?></span></td><td><?php echo e($row['accuracy'] ?: '-'); ?></td><td class="text-muted"><small><?php echo e($row['scanned_at']); ?></small></td></tr><?php endforeach; else: ?><tr><td colspan="7" class="text-center text-muted py-5">No scan records found for this period.</td></tr><?php endif; ?>
            </tbody></table></div>
            <div class="report-footer"><span>Generated by SecuScan Admin Panel</span><span>Generated: <?php echo date('d M Y, h:i A'); ?></span></div>
        </section>
        <?php endif; ?>

        <?php if ($admin_page === 'url-history'): ?>
        <section id="url-history" class="panel-card p-4 mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3"><div><h4 class="fw-bold mb-1"><i class="fa-solid fa-link text-primary me-2"></i>URL Scan History</h4><small class="text-muted">50 latest URL records from all users.</small></div><span class="badge text-bg-primary rounded-pill">URL</span></div>
            <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>User</th><th>URL</th><th>Result</th><th>Timestamp</th></tr></thead><tbody>
            <?php if ($all_url_logs && $all_url_logs->num_rows > 0): while ($row = $all_url_logs->fetch_assoc()): ?><tr><td><?php echo e($row['username'] ?: 'Guest'); ?></td><td class="code-font text-break" style="max-width:360px"><?php echo e($row['url']); ?></td><td><span class="badge <?php echo result_badge_class($row['hasil_pemeriksaan']); ?> rounded-pill"><?php echo e($row['hasil_pemeriksaan']); ?></span></td><td class="text-muted"><small><?php echo e($row['tarikh_semak']); ?></small></td></tr><?php endwhile; else: ?><tr><td colspan="4" class="text-center text-muted py-4">No URL scan records found.</td></tr><?php endif; ?>
            </tbody></table></div>
        </section>
        <?php endif; ?>

        <?php if ($admin_page === 'file-history'): ?>
        <section id="file-history" class="panel-card p-4 mb-5">
            <div class="d-flex justify-content-between align-items-center mb-3"><div><h4 class="fw-bold mb-1"><i class="fa-solid fa-file-shield text-warning me-2"></i>File Scan History</h4><small class="text-muted">50 latest file records from all users.</small></div><span class="badge text-bg-warning rounded-pill">FILE</span></div>
            <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>User</th><th>Filename</th><th>SHA-256 Hash</th><th>Result</th><th>Timestamp</th></tr></thead><tbody>
            <?php if ($all_file_logs && $all_file_logs->num_rows > 0): while ($row = $all_file_logs->fetch_assoc()): ?><tr><td><?php echo e($row['username'] ?: 'Guest'); ?></td><td class="fw-semibold"><?php echo e($row['filename']); ?></td><td class="code-font text-muted"><?php echo e(substr($row['file_hash'], 0, 18)); ?>...</td><td><span class="badge <?php echo result_badge_class($row['hasil_pemeriksaan']); ?> rounded-pill"><?php echo e($row['hasil_pemeriksaan']); ?></span></td><td class="text-muted"><small><?php echo e($row['tarikh_semak']); ?></small></td></tr><?php endwhile; else: ?><tr><td colspan="5" class="text-center text-muted py-4">No file scan records found.</td></tr><?php endif; ?>
            </tbody></table></div>
        </section>
        <?php endif; ?>

        <?php if ($admin_page === 'hash-history'): ?>
        <section id="hash-history" class="panel-card p-4 mb-5">
            <div class="d-flex justify-content-between align-items-center mb-3"><div><h4 class="fw-bold mb-1"><i class="fa-solid fa-fingerprint text-primary me-2"></i>Hash Scan History</h4><small class="text-muted">50 latest hash records from all users.</small></div><span class="badge text-bg-primary rounded-pill">HASH</span></div>
            <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>User</th><th>Filename</th><th>Hash</th><th>Result</th><th>Timestamp</th></tr></thead><tbody>
            <?php if ($all_hash_logs && $all_hash_logs->num_rows > 0): while ($row = $all_hash_logs->fetch_assoc()): ?><tr><td><?php echo e($row['username'] ?: 'Guest'); ?></td><td><?php echo e($row['filename'] ?: 'Hash input'); ?></td><td class="code-font text-muted"><?php echo e($row['file_hash']); ?></td><td><span class="badge <?php echo result_badge_class($row['verdict']); ?> rounded-pill"><?php echo e($row['verdict']); ?></span></td><td class="text-muted"><small><?php echo e($row['scanned_at']); ?></small></td></tr><?php endwhile; else: ?><tr><td colspan="5" class="text-center text-muted py-4">No hash scan records found.</td></tr><?php endif; ?>
            </tbody></table></div>
        </section>
        <?php endif; ?>

        <?php if ($admin_page === 'ip-history'): ?>
        <section id="ip-history" class="panel-card p-4 mb-5">
            <div class="d-flex justify-content-between align-items-center mb-3"><div><h4 class="fw-bold mb-1"><i class="fa-solid fa-globe text-primary me-2"></i>IP Scan History</h4><small class="text-muted">50 latest IP records from all users.</small></div><span class="badge text-bg-primary rounded-pill">IP</span></div>
            <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>User</th><th>IP Address</th><th>Country</th><th>Abuse Score</th><th>Result</th><th>Timestamp</th></tr></thead><tbody>
            <?php if ($all_ip_logs && $all_ip_logs->num_rows > 0): while ($row = $all_ip_logs->fetch_assoc()): ?><tr><td><?php echo e($row['username'] ?: 'Guest'); ?></td><td class="code-font"><?php echo e($row['ip_address']); ?></td><td><?php echo e($row['country_code'] ?: '-'); ?></td><td><?php echo (int) $row['abuse_score']; ?>/100</td><td><span class="badge <?php echo result_badge_class($row['verdict']); ?> rounded-pill"><?php echo e($row['verdict']); ?></span></td><td class="text-muted"><small><?php echo e($row['scanned_at']); ?></small></td></tr><?php endwhile; else: ?><tr><td colspan="6" class="text-center text-muted py-4">No IP scan records found.</td></tr><?php endif; ?>
            </tbody></table></div>
        </section>
        <?php endif; ?>

    </main>
</div>
</body></html>