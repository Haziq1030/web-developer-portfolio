# SecuScan — Threat Intelligence Integration

Adds three modules to the existing SecuScan app:

| Module | Provider(s) | What it replaces |
|---|---|---|
| **Hash Scanner** | VirusTotal + MetaDefender | The 3-hardcoded-hash "malware scanner" in `scan_file_live.py` |
| **IP Scanner** | AbuseIPDB | New capability |
| **Cybersecurity News** | RSS aggregation | New capability |

---

## 1. File layout

Drop these into your SecuScan folder (`C:\xampp\htdocs\Secuscan\`):

```
Secuscan/
├── config.php              ← your keys live here. NEVER commit this.
├── config.example.php      ← the committable template
├── .htaccess               ← blocks .pkl / .csv / .sql / config.php downloads
├── .gitignore
├── api_setup.sql           ← run once
├── api_test.php            ← open this FIRST, delete before deploying
├── services/
│   ├── ThreatResult.php        normalized verdict shape
│   ├── HttpClient.php          cURL wrapper, strict TLS
│   ├── ApiCache.php            response cache + rate limiter
│   ├── VirusTotalService.php
│   ├── MetaDefenderService.php
│   ├── AbuseIPDBService.php
│   ├── NewsService.php
│   └── ScanHandlers.php        POST handlers + CSRF helpers
└── pages/
    ├── scan-hash.php
    ├── scan-ip.php
    └── news.php
```

---

## 2. Setup, in order

**Step 1 — database.** In phpMyAdmin, select `secuscan_db`, open the SQL tab, paste `api_setup.sql`, run.
It creates 4 tables and fixes several issues from the review (missing indexes, the truncating
`url VARCHAR(255)`, the one corrupted `file_hash` row).

**Step 2 — enable cURL.** Open `C:\xampp\php\php.ini`, find `;extension=curl`, remove the `;`, restart Apache.

**Step 3 — fix TLS.** XAMPP for Windows ships without a CA bundle, so every HTTPS call fails with
*"SSL certificate problem: unable to get local issuer certificate"*. Download
<https://curl.se/ca/cacert.pem>, save it to `C:\xampp\php\extras\ssl\cacert.pem`, then in `config.php`:

```php
const CA_BUNDLE_PATH = 'C:/xampp/php/extras/ssl/cacert.pem';
```

Do **not** "fix" this by setting `CURLOPT_SSL_VERIFYPEER => false`. That switch is the only thing
stopping someone on your network from impersonating VirusTotal and feeding your scanner fake verdicts.

**Step 4 — run diagnostics.** Log in as admin, open `http://localhost/Secuscan/api_test.php`.
It checks PHP extensions, TLS, the 4 tables, all three API keys against the EICAR test hash and
`1.1.1.1`, and every news feed URL. Fix anything red before continuing.

**Step 5 — wire up `index.php`.** Five edits below.

---

## 3. Edits to `index.php`

### 3a. Top of file — replace the connection block

Find lines 81–83:

```php
$conn = mysqli_connect('localhost', 'root', '', 'secuscan_db');
if (!$conn) die('Gagal disambung ke database: ' . mysqli_connect_error());
mysqli_set_charset($conn, 'utf8mb4');
```

Replace with:

```php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/services/ScanHandlers.php';

try {
    $conn = secuscan_db();
} catch (Throwable $ex) {
    // Never echo the driver message — it leaks host, user and schema.
    error_log('SecuScan DB error: ' . $ex->getMessage());
    http_response_code(503);
    exit('The service is temporarily unavailable. Please try again shortly.');
}
```

### 3b. Register the new pages

Find line 90:

```php
$allowed_pages = ['dashboard', 'scan-link', 'scan-file', 'awareness', 'contact', 'complain'];
```

Replace with:

```php
$allowed_pages = ['dashboard', 'scan-link', 'scan-file', 'scan-hash', 'scan-ip', 'news', 'awareness', 'contact', 'complain'];
```

### 3c. Run the handlers — put this right after the `$allowed_pages` block

```php
$hash_scan = handle_hash_scan($user_id);
if ($hash_scan !== null) { $page = 'scan-hash'; }

$ip_scan = handle_ip_scan($user_id);
if ($ip_scan !== null) { $page = 'scan-ip'; }
```

### 3d. Sidebar menu

Find the `$menu` array on lines 194–198 and add three entries:

```php
$menu = [
    'dashboard' => ['Dashboard', 'fa-chart-line'],
    'scan-link' => ['Scan Link', 'fa-link'],
    'scan-file' => ['Scan File', 'fa-file-shield'],
    'scan-hash' => ['Hash Scanner', 'fa-fingerprint'],      // new
    'scan-ip'   => ['IP Scanner', 'fa-globe'],              // new
    'news'      => ['Cybersecurity News', 'fa-newspaper'],  // new
    'awareness' => ['Cybersecurity Info & Awareness', 'fa-lightbulb'],
    'contact'   => ['Contact Us', 'fa-headset'],
    'complain'  => ['Complain & Feedback', 'fa-message'],
];
```

### 3e. Render the pages

In the `<main>` routing chain, before the final `<?php else: ?>`, add:

```php
<?php elseif ($page === 'scan-hash'): ?>
    <?php include __DIR__ . '/pages/scan-hash.php'; ?>

<?php elseif ($page === 'scan-ip'): ?>
    <?php include __DIR__ . '/pages/scan-ip.php'; ?>

<?php elseif ($page === 'news'): ?>
    <?php include __DIR__ . '/pages/news.php'; ?>
```

`$hash_scan` and `$ip_scan` must exist even when nothing was submitted, so add this near the top of
the render section:

```php
$hash_scan = $hash_scan ?? null;
$ip_scan   = $ip_scan   ?? null;
```

---

## 4. Design decisions worth defending

### Four verdicts, not two

The old engine had `Safe` and `Phishing`/`Malware`. Anything that was not a positive detection —
including a crashed Python script — became **Safe**. That is fail-open, the worst possible default
for a security tool.

This version has five states and only one of them means "checked and found nothing":

| Verdict | Meaning |
|---|---|
| `malicious` | A provider positively flagged it |
| `suspicious` | Weak or partial signal |
| `clean` | Looked up successfully, nothing found |
| `unknown` | Never seen by any provider — **not the same as clean** |
| `error` | The lookup failed — **not a verdict at all** |

A VirusTotal 404 means the file has never been submitted. Brand-new malware returns 404. The UI says
so explicitly rather than showing a green tick.

### No invented confidence number

The old code printed `99.90%` and `100.00%` as hardcoded strings. If a panel asks how those were
calculated, there is no answer.

Every number here is a real ratio with a stated denominator — "63 of 77 engines flagged this file",
"abuse confidence 100%, from 245 reports by 52 distinct reporters". The combined verdict deliberately
does **not** blend providers into a single percentage; each provider's own figure appears next to
its own name.

### Files never leave the machine

The hash scanner computes SHA-256 locally with `hash_file()`, deletes the temp file, and sends only
the 64-character digest. Uploading a document to a public scanning service would publish its contents
to every VirusTotal Intelligence subscriber. Hash-only lookup avoids that entirely, and the UI says so.

### Cache before quota

VirusTotal's public tier allows **4 requests per minute**. Without a cache, one person refreshing a
results page exhausts it and every later scan errors out — your demo dies in under a minute.

`ApiCache` stores responses keyed on `(provider, indicator)` and checks a local ledger before each
call, so repeats are free and an exhausted quota produces a clear message instead of a 429. The scanner
pages show live quota usage.

---

## 5. Test values

| Input | Expected |
|---|---|
| `275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f` | EICAR — Malicious, ~60+ engines |
| `44d88612fea8a8f36de82e1278abb02f` | EICAR MD5 — same file, proves MD5 input works |
| Any random 64 hex chars | Unknown — proves 404 ≠ clean |
| `1.1.1.1` | Cloudflare DNS — low/zero abuse score |
| `118.25.6.39` | Frequently reported — high abuse score, SSH/brute-force categories |
| `192.168.1.1` | Private range — rejected before any API call is made |

EICAR is a harmless 68-byte text string that every antivirus detects by agreement. Use it instead of
real malware. Create it with:

```
echo X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H* > eicar.txt
```

Windows Defender will quarantine it immediately — that is the file working as designed.

---

## 6. Still outstanding from the code review

These are **not** fixed by this package and remain open:

1. **`login.php:23`** — delete `|| md5($password) === $user['password']`.
2. **Admin password** is the MD5 of `admin123`. Generate a new hash and update the row:
   `php -r "echo password_hash('YourNewPassword', PASSWORD_DEFAULT);"`
3. **`register.php:11-13`** — delete the three `putenv()` lines; the keys come from `config.php` now.
4. **`register.php:90`** — remove the fallback that prints the verification link on screen. Right now
   anyone can register and self-verify.
5. **`register.php:15-17`** — replace the three `require_once` lines with `require 'vendor/autoload.php'`;
   the hardcoded `PHPMailer-6.9.2` path does not match the v7.1.1 that Composer installed.
6. **Delete** `composer.phar`, `composer-setup.php`, `gmail_setup_example.php` (it calls `phpinfo()`),
   and `semak_dan_simpan.py` (dead file that predicts without the scaler).
7. **Move** `model_secuscan.pkl`, `scaler.pkl`, `phishing_url_dataset.csv` and `secuscan_db.sql`
   out of the web root. The `.htaccess` blocks them, but out-of-root is the real fix.
8. **Retrain the URL model.** It currently classifies everything as phishing — see the dataset notes:
   45% duplicate rows, and `isHttps`/`valid_url` are inverted relative to reality.
9. **CSRF** — `csrf_field()` and `csrf_valid()` are in `ScanHandlers.php` and already protect the new
   forms. Apply them to the complaint form and the admin status form too.
10. **Rate-limit login.** The same `api_rate_log` pattern works: log failed attempts per username/IP
    and refuse after 5 in 15 minutes.
