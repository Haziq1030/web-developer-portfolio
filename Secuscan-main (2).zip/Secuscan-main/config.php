<?php
/**
 * SecuScan — central configuration.
 *
 * SECURITY:
 *   1. This file contains live API keys. It must NEVER be committed to git.
 *      The bundled .gitignore already excludes it. Commit config.example.php instead.
 *   2. The bundled .htaccess blocks direct HTTP access to this file. Verify by
 *      visiting http://localhost/Secuscan/config.php — you must get 403, not a blank page.
 *   3. Better still: move this file one level ABOVE htdocs and change the require
 *      path in your PHP files to __DIR__ . '/../config.php'.
 */

// ---------------------------------------------------------------------------
// DATABASE
// ---------------------------------------------------------------------------
const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'secuscan_db';

// ---------------------------------------------------------------------------
// THIRD-PARTY THREAT INTELLIGENCE KEYS
// ---------------------------------------------------------------------------
// Prefer environment variables in any real deployment. getenv() wins when set,
// so you can override these without editing the file.
// NOTE: do NOT use putenv() here — it overwrites the environment and makes the
// getenv() fallback dead code (that was the bug in the old register.php).

const VIRUSTOTAL_API_KEY  = '8a2e2eb5bd0d85dd6400863dba39339923a674ee9200cf954672e3ad6d38b686';
const ABUSEIPDB_API_KEY   = 'cadae7849c308a5e019e3ebbeb0d3bfd6e2e11d73a0b9a31521e43aaae3fac9ca25b595b9b3e7a94';
const METADEFENDER_API_KEY = '41813d215fc6b17fa0788846e8ebfdb9';
const AI_ASSIST_API_KEY   = 'AQ.Ab8RN6KymIZ5oVabtr8YeDKHkepz5vuQUMsvpVBePmy7Dpq1Dw';

// Free Auth-Key from https://auth.abuse.ch/ — powers the global layer of the
// threat map. Leave empty and the map still works, showing campus scans only.
const THREATFOX_API_KEY   = '0fb308b33e4ebc92a1a3647d1d8650d35ce4ca7d2908dcec';

// ---------------------------------------------------------------------------
// AI ASSIST
// ---------------------------------------------------------------------------
// Which vendor the key above belongs to. The 'AQ.' prefix is the current
// Google AI Studio format, so 'gemini' is the default. If api_test.php reports
// HTTP 401/403, change this one line and retest — nothing else needs editing.
//   'gemini' | 'openai' | 'groq'
const AI_PROVIDER = 'gemini';

// Preferred models, most-wanted first. For Gemini the app does NOT trust this
// list blindly: on first use it asks the API which models the key can actually
// reach, picks the best match from here, and caches the answer. Model names are
// retired and renamed regularly, so hardcoding one guarantees a 404 eventually.
// Leave the list alone unless you have a reason; discovery handles the rest.
const AI_MODELS = [
    'gemini' => [
        // First choice, and confirmed against the cURL quickstart that Google
        // itself generates for this project's key. An alias like this tracks
        // whatever the current flash model is, so it does not rot the way a
        // pinned version number does — which is exactly what caused the 404.
        'gemini-flash-latest',
        'gemini-2.5-flash',
        'gemini-2.0-flash',
        'gemini-2.0-flash-001',
        'gemini-1.5-flash',
    ],
    'openai' => ['gpt-4o-mini'],
    'groq'   => ['llama-3.3-70b-versatile'],
];

// Guardrails. Students share this quota, so keep replies short and capped.
const AI_MAX_QUESTION_CHARS = 1000;  // reject longer input before spending a call
const AI_MAX_REPLY_TOKENS   = 700;
const AI_HISTORY_TURNS      = 6;     // how many past messages are sent for context
const AI_TEMPERATURE        = 0.3;   // low: factual, not creative

function secuscan_key(string $name): string
{
    $fromEnv = getenv('SECUSCAN_' . $name);
    if (is_string($fromEnv) && $fromEnv !== '') {
        return $fromEnv;
    }
    switch ($name) {
        case 'VIRUSTOTAL_API_KEY':   return VIRUSTOTAL_API_KEY;
        case 'ABUSEIPDB_API_KEY':    return ABUSEIPDB_API_KEY;
        case 'METADEFENDER_API_KEY': return METADEFENDER_API_KEY;
        case 'AI_ASSIST_API_KEY':    return AI_ASSIST_API_KEY;
        case 'THREATFOX_API_KEY':    return THREATFOX_API_KEY;
    }
    return '';
}

// ---------------------------------------------------------------------------
// RATE LIMITS (free tiers — adjust if you upgrade)
// ---------------------------------------------------------------------------
// VirusTotal public API: 4 requests/minute, 500/day.
// MetaDefender free:     ~10 requests/minute (hash lookups are cheap).
// AbuseIPDB free:        1000 checks/day.
const RATE_LIMITS = [
    'virustotal'   => ['per_minute' => 4,  'per_day' => 500],
    'metadefender' => ['per_minute' => 10, 'per_day' => 1000],
    'abuseipdb'    => ['per_minute' => 60, 'per_day' => 1000],
    // Shared campus quota: one student cannot drain the day for everyone.
    'ai'           => ['per_minute' => 10, 'per_day' => 400],
    'threatfox'    => ['per_minute' => 4,  'per_day' => 200],
];

// How long the discovered model name stays cached before it is re-checked.
const AI_MODEL_CACHE_TTL = 604800; // 7 days

// ---------------------------------------------------------------------------
// PROVIDER LABELLING (white-labelling)
// ---------------------------------------------------------------------------
// false = students see neutral engine names instead of vendor brands.
// Administrator pages (api_test.php, ai_debug.php) always show the real names,
// because hiding them there would make the tool impossible to support.
//
// READ THIS BEFORE SHIPPING: the free tiers of VirusTotal and AbuseIPDB both
// ask for attribution when you display their results. Hiding the names on each
// result card is fine, but keep the credit line below somewhere public — the
// Contact or About page is the usual place. It costs you nothing and keeps the
// campus on the right side of their terms.
const SHOW_PROVIDER_NAMES = false;

const PROVIDER_LABELS = [
    'VirusTotal'   => 'First Engine',
    'MetaDefender' => 'Second Engine',
    'AbuseIPDB'    => 'IP Reputation Database',
];

// ---------------------------------------------------------------------------
// THREAT MAP
// ---------------------------------------------------------------------------
// Sequential blue ramp, low -> high. Validated against this app's dark surface
// (#080c14): monotone lightness, visible step gaps, single hue, and the step
// nearest the surface clears 3.6:1 so the legend swatches stay readable.
//
// Blue, not red, is deliberate. A map where every country glows red reads as
// danger everywhere and tells the viewer nothing — that is what makes most
// public "attack maps" theatre. This ramp encodes VOLUME OF OBSERVATIONS, and
// the page says so plainly.
const MAP_RAMP = ['#256abf', '#3987e5', '#6da7ec', '#9ec5f4', '#cde2fb'];

// Country with no data at all — recedes toward the surface.
const MAP_EMPTY_FILL = '#16243c';

// Rendered on the Contact page. Keep it even when SHOW_PROVIDER_NAMES is false —
// several of these providers require attribution in their free-tier terms, and
// MaxMind's licence requires the GeoLite2 line specifically.
const PROVIDER_CREDITS = 'Threat intelligence supplied by VirusTotal, OPSWAT MetaDefender, AbuseIPDB and abuse.ch. '
    . 'This product includes GeoLite2 data created by MaxMind, available from https://www.maxmind.com.';

// Per-student ceiling, enforced on top of the shared limit above.
const AI_PER_USER_HOURLY = 25;

// How long a cached provider response stays fresh, in seconds.
// Hash verdicts are stable; IP reputation moves faster; news fastest.
const CACHE_TTL = [
    'virustotal'   => 86400,   // 24 hours
    'metadefender' => 86400,   // 24 hours
    'abuseipdb'    => 21600,   // 6 hours
    'news'         => 1800,    // 30 minutes
    'ai_model'     => 604800,  // 7 days — the discovered model name
    'threatfox'    => 3600,    // 1 hour — the global IOC snapshot
];

// ---------------------------------------------------------------------------
// HTTP CLIENT
// ---------------------------------------------------------------------------
const HTTP_TIMEOUT = 20;          // seconds, total
const HTTP_CONNECT_TIMEOUT = 8;   // seconds

// Identify the app honestly, in the conventional bot format. Several publishers
// sit behind CDNs that reject unrecognised User-Agent strings outright — that is
// what produced the 403 on the CISA feed. This says what we are and where to
// complain, which is what those filters are actually looking for.
const HTTP_USER_AGENT = 'Mozilla/5.0 (compatible; SecuScanBot/2.0; +https://secuscan.local/about) RSS-Reader';

// XAMPP on Windows ships without a CA bundle, so every HTTPS call fails with
// "SSL certificate problem: unable to get local issuer certificate".
// Fix properly: download https://curl.se/ca/cacert.pem, save it, point here.
// Do NOT "fix" it by disabling CURLOPT_SSL_VERIFYPEER — that removes the only
// thing stopping an attacker from impersonating VirusTotal to your scanner.
const CA_BUNDLE_PATH = ''; // e.g. 'C:/xampp/php/extras/ssl/cacert.pem'

// ---------------------------------------------------------------------------
// NEWS FEEDS
// ---------------------------------------------------------------------------
// Each entry: [label, url, region]. Verify each URL resolves via api_test.php —
// feed URLs change and a dead feed is skipped silently.
// Verified working on your install. Add or remove freely — api_test.php probes
// every URL here and reports which ones answer.
const NEWS_FEEDS = [
    ['The Hacker News',   'https://feeds.feedburner.com/TheHackersNews',  'Global'],
    ['BleepingComputer',  'https://www.bleepingcomputer.com/feed/',       'Global'],
    ['Krebs on Security', 'https://krebsonsecurity.com/feed/',            'Global'],
    ['Dark Reading',      'https://www.darkreading.com/rss.xml',          'Global'],
    ['The Record',        'https://therecord.media/feed',                 'Global'],
    // Vendor security research. Blogger feeds use a fixed path, so this one is
    // as stable as feed URLs get — but verify it in api_test.php like any other.
    ['Google Security',   'https://security.googleblog.com/feeds/posts/default', 'Research'],

    // CISA was removed. Its CDN returns 403 to server-side requests regardless
    // of the User-Agent sent — it is not a broken URL, it is a deliberate block
    // on non-browser traffic. Nothing is lost: the KEV additions CISA publishes
    // are covered by The Hacker News and BleepingComputer within hours.
    //
    // CANDIDATES, UNVERIFIED. I could not reach any feed host from where this
    // was written, so none of the URLs below were tested. Paste one in, open
    // api_test.php, and keep it only if that page says OK.
    //
    // ['SANS Storm Center', 'https://isc.sans.edu/rssfeed.xml',                 'Advisory'],
    // ['Unit 42',           'https://unit42.paloaltonetworks.com/feed/',        'Research'],
    // ['Securelist',        'https://securelist.com/feed/',                     'Research'],
    // ['WeLiveSecurity',    'https://www.welivesecurity.com/en/rss/feed/',      'Research'],
    // ['Schneier',          'https://www.schneier.com/feed/',                   'Commentary'],
    //
    // For a Malaysian angle, MyCERT and NACSA are the sources worth adding.
    // Find their current feed URL on the site itself rather than trusting a
    // guess from me — then verify it the same way.
];

const NEWS_MAX_ITEMS = 40;

// ---------------------------------------------------------------------------
// COUNTRY DETECTION FOR NEWS
// ---------------------------------------------------------------------------
// Keyword matching over the headline and summary. This is a rough signal, not
// a classification: an article can mention a country in passing and still be
// tagged with it, and one that never names a country stays untagged. The page
// says so rather than pretending the tags are authoritative.
//
// Keep the keywords specific. Short or ambiguous ones ("us", "in", "ncsc")
// cause far more wrong tags than the extra coverage is worth.
const NEWS_COUNTRIES = [
    'Malaysia'    => ['malaysia', 'malaysian', 'mycert', 'nacsa', 'kuala lumpur'],
    'Singapore'   => ['singapore', 'singaporean'],
    'Indonesia'   => ['indonesia', 'indonesian', 'jakarta'],
    'Thailand'    => ['thailand', 'thai government', 'bangkok'],
    'Philippines' => ['philippines', 'filipino', 'manila'],
    'Vietnam'     => ['vietnam', 'vietnamese', 'hanoi'],
    'China'       => ['china', 'chinese', 'beijing', 'prc '],
    'Japan'       => ['japan', 'japanese', 'tokyo'],
    'South Korea' => ['south korea', 'korean', 'seoul'],
    'North Korea' => ['north korea', 'lazarus group', 'pyongyang', 'dprk'],
    'India'       => ['india', 'indian', 'cert-in', 'new delhi'],
    'Australia'   => ['australia', 'australian', 'canberra'],
    'United States' => ['united states', 'u.s. government', 'cisa', 'fbi ', 'nsa ', 'washington'],
    'United Kingdom' => ['united kingdom', 'britain', 'british', 'london'],
    'Netherlands' => ['netherlands', 'dutch'],
    'Germany'     => ['germany', 'german ', 'berlin', 'bsi '],
    'France'      => ['france', 'french ', 'paris'],
    'Russia'      => ['russia', 'russian', 'moscow', 'kremlin'],
    'Ukraine'     => ['ukraine', 'ukrainian', 'kyiv'],
    'Israel'      => ['israel', 'israeli'],
    'Canada'      => ['canada', 'canadian', 'ottawa'],
];

// Countries listed here always appear in the filter bar, even with no articles,
// so the local angle is visible rather than buried behind a busy week abroad.
const NEWS_PINNED_COUNTRIES = ['Malaysia', 'Singapore'];

// ---------------------------------------------------------------------------
// SHARED DB HANDLE
// ---------------------------------------------------------------------------
function secuscan_db(): mysqli
{
    static $conn = null;
    if ($conn instanceof mysqli) {
        return $conn;
    }
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
    return $conn;
}
