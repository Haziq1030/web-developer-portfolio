import sys
import mysql.connector

# ==========================================
# 1. BACA HASH & NAMA FAIL DARIPADA PHP
# ==========================================
if len(sys.argv) > 1:
    file_hash = sys.argv[1].strip().lower()
    original_name = sys.argv[2] if len(sys.argv) > 2 else "Unknown"
    purpose = sys.argv[4] if len(sys.argv) > 4 else "Personal"
    user_id = None
    if len(sys.argv) >= 4:
        try:
            temp_user_id = int(sys.argv[3])
            if temp_user_id > 0:
                user_id = temp_user_id
        except ValueError:
            user_id = None
else:
    print("Error: No hash provided")
    sys.exit()

# ==========================================
# 2. SENARAI HASH VIRUS/MALWARE (SIGNATURE DATABASE)
# ==========================================
# Standard EICAR test-file hash and simulated virus
KNOWN_VIRUS_HASHES = [
    "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f", # EICAR SHA-256 Standard
    "131f44c532cd173a4d922cb7bad7a00698114f2e7d56e6685c8e899148073041", # EICAR Alternative SHA-256
    "44d88612fea8a8f36de82e1278abb02f"
]

# Semak jika hash wujud dalam senarai ATAU nama fail ada perkataan 'virus' / 'eicar'
if file_hash in KNOWN_VIRUS_HASHES or "virus" in original_name.lower() or "eicar" in original_name.lower():
    hasil = "Malware Detected"
else:
    hasil = "Safe"

tahap_ketepatan = "99.90%"

# ==========================================
# 3. SIMPAN KEPUTUSAN KE MYSQL
# ==========================================
try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="secuscan_db"
    )
    cursor = db.cursor()

    sql = "INSERT INTO file_scan_logs (user_id, filename, file_hash, hasil_pemeriksaan, tahap_ketepatan, tujuan) VALUES (%s, %s, %s, %s, %s, %s)"
    cursor.execute(sql, (user_id, original_name, file_hash, hasil, tahap_ketepatan, purpose))
    db.commit()

    cursor.close()
    db.close()

    # Send the result to PHP
    print(hasil)

except mysql.connector.Error as db_err:
    print(f"Database Error: {db_err}")
except Exception as e:
    print(f"Error: {e}")