USE secuscan_db;

-- Purpose analytics columns. Existing rows automatically use Personal.
ALTER TABLE scan_logs
    ADD COLUMN IF NOT EXISTS tujuan VARCHAR(50) NOT NULL DEFAULT 'Personal' AFTER tahap_ketepatan;

ALTER TABLE file_scan_logs
    ADD COLUMN IF NOT EXISTS tujuan VARCHAR(50) NOT NULL DEFAULT 'Personal' AFTER tahap_ketepatan;

UPDATE scan_logs SET tujuan = 'Personal' WHERE tujuan IS NULL OR tujuan = '';
UPDATE file_scan_logs SET tujuan = 'Personal' WHERE tujuan IS NULL OR tujuan = '';

-- Complaints table used by index.php and admin.php.
CREATE TABLE IF NOT EXISTS complaints (
    id INT NOT NULL AUTO_INCREMENT,
    user_id INT DEFAULT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    category VARCHAR(80) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('New', 'In Progress', 'Resolved') NOT NULL DEFAULT 'New',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_complaints_user_id (user_id),
    INDEX idx_complaints_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Verify analytics data.
SELECT tujuan, COUNT(*) AS jumlah FROM scan_logs GROUP BY tujuan;
SELECT tujuan, COUNT(*) AS jumlah FROM file_scan_logs GROUP BY tujuan;
