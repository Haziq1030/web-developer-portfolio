<?php
/**
 * SecuScan — one-time importer for the MaxMind GeoLite2 Country CSV.
 *
 * HOW TO USE
 *   1. Download "GeoLite2 Country: CSV Format" from your MaxMind account.
 *   2. Unzip it. Put these two files in the same folder as this script:
 *        GeoLite2-Country-Blocks-IPv4.csv
 *        GeoLite2-Country-Locations-en.csv
 *   3. Log in as admin, open this page, press Import.
 *
 * The blocks file is around 400,000 rows, so the import runs in batches with a
 * progress page rather than one request that would hit any time limit you set.
 *
 * DELETE THIS FILE once the import is done — it is a bulk database writer and
 * has no business being reachable afterwards.
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');
@set_time_limit(0);
session_start();

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/services/GeoIpService.php';


const BLOCKS_CSV    = __DIR__ . '/GeoLite2-Country-Blocks-IPv4.csv';
const LOCATIONS_CSV = __DIR__ . '/GeoLite2-Country-Locations-en.csv';
const BATCH_ROWS    = 40000;   // rows per request (~14 batches for the current file)

function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }

$conn = secuscan_db();
$action = $_GET['action'] ?? '';
$offset = max(0, (int) ($_GET['offset'] ?? 0));
$message = '';
$done = false;
$imported = 0;

/**
 * Confirm the tables exist before touching them.
 *
 * Without this the first TRUNCATE throws a raw mysqli_sql_exception with a
 * stack trace — technically accurate, useless to read, and it leaks the
 * filesystem path. A missing table here means one specific thing, so say it.
 */
$missingTables = [];
foreach (['geoip_country', 'geoip_block'] as $table) {
    $res = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");
    if (!$res || $res->num_rows === 0) {
        $missingTables[] = $table;
    }
}
$schemaReady = empty($missingTables);

if (!$schemaReady) {
    // Refuse to run either step; the page below explains what to do.
    $action = '';
}

// ---------------------------------------------------------------------------
// Step 1 — countries (small file, one pass)
// ---------------------------------------------------------------------------
if ($action === 'locations') {
    if (!is_readable(LOCATIONS_CSV)) {
        $message = 'Cannot read ' . basename(LOCATIONS_CSV) . ' — is it in this folder?';
    } else {
        $fh = fopen(LOCATIONS_CSV, 'r');
        $header = fgetcsv($fh);                       // discard the header row
        $conn->query('TRUNCATE TABLE geoip_country');

        $stmt = $conn->prepare(
            'INSERT INTO geoip_country (geoname_id, iso_code, country_name, continent)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE iso_code = VALUES(iso_code), country_name = VALUES(country_name)'
        );
        $conn->begin_transaction();
        while (($row = fgetcsv($fh)) !== false) {
            // geoname_id, locale_code, continent_code, continent_name,
            // country_iso_code, country_name, is_in_european_union
            if (count($row) < 6) { continue; }
            $gid = (int) $row[0];
            $iso = strtoupper(substr((string) $row[4], 0, 2));
            $name = (string) $row[5];
            $cont = (string) $row[3];
            if ($gid === 0 || $iso === '') { continue; }
            $stmt->bind_param('isss', $gid, $iso, $name, $cont);
            $stmt->execute();
            $imported++;
        }
        $conn->commit();
        $stmt->close();
        fclose($fh);
        $message = number_format($imported) . ' countries imported.';
    }
}

// ---------------------------------------------------------------------------
// Step 2 — IP blocks, in batches
// ---------------------------------------------------------------------------
if ($action === 'blocks') {
    if (!is_readable(BLOCKS_CSV)) {
        $message = 'Cannot read ' . basename(BLOCKS_CSV) . ' — is it in this folder?';
    } else {
        $fh = fopen(BLOCKS_CSV, 'r');

        if ($offset === 0) {
            $conn->query('TRUNCATE TABLE geoip_block');
            fgetcsv($fh);                              // discard the header once
        } else {
            // Resume at a BYTE offset, not a row count.
            //
            // Re-reading N rows to reach batch N is O(n^2): this file is
            // ~564,000 rows, so row-counting would re-parse about 6 million
            // lines across the run for no reason. fseek makes each batch cost
            // only the rows it actually imports.
            fseek($fh, $offset);
        }

        $stmt = $conn->prepare(
            'INSERT INTO geoip_block (start_ip, end_ip, geoname_id) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE end_ip = VALUES(end_ip), geoname_id = VALUES(geoname_id)'
        );
        $conn->begin_transaction();
        $read = 0;
        while ($read < BATCH_ROWS && ($row = fgetcsv($fh)) !== false) {
            $read++;
            // network, geoname_id, registered_country_geoname_id, ...
            if (count($row) < 2) { continue; }
            $range = GeoIpService::cidrRange((string) $row[0]);
            if ($range === null) { continue; }

            // Fall back to the registered country when the block itself has no
            // geoname — otherwise whole ranges silently vanish from the map.
            $gid = (int) ($row[1] !== '' ? $row[1] : ($row[2] ?? 0));
            if ($gid === 0) { continue; }

            $stmt->bind_param('iii', $range[0], $range[1], $gid);
            $stmt->execute();
            $imported++;
        }
        $conn->commit();
        $stmt->close();

        // Where to resume next time, and whether anything is left.
        $nextOffset = ftell($fh);
        $more = !feof($fh) && fgetcsv($fh) !== false;
        fclose($fh);

        $totalSoFar = (int) ($conn->query('SELECT COUNT(*) AS t FROM geoip_block')->fetch_assoc()['t'] ?? 0);

        if ($more) {
            header('Refresh: 0; url=import_geolite.php?action=blocks&offset=' . $nextOffset);
            $pct = filesize(BLOCKS_CSV) > 0 ? round($nextOffset / filesize(BLOCKS_CSV) * 100) : 0;
            $message = number_format($totalSoFar) . ' blocks imported (' . $pct . '% of the file)…';
        } else {
            $done = true;
            $message = 'Finished. ' . number_format($totalSoFar) . ' blocks imported in total.';
        }
    }
}

$stats = ['blocks' => 0, 'countries' => 0];
if ($schemaReady) {
    try { $stats = GeoIpService::stats(); } catch (Throwable $ex) { $message = $message ?: 'Could not read the tables.'; }
}
$filesReady = is_readable(BLOCKS_CSV) && is_readable(LOCATIONS_CSV);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>GeoLite2 Import</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{background:linear-gradient(135deg,#f8fbff 0%,#eef4ff 45%,#f1f5f9 100%);color:#0f172a;padding:36px 16px}
    .card{background:rgba(255,255,255,.96);border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 18px 42px rgba(15,23,42,.05)}
    code{color:#2563eb}
  </style>
</head>
<body>
<div class="container" style="max-width:760px">
  <h1 class="fw-bold mb-4">GeoLite2 Country import</h1>

  <?php if (!$schemaReady): ?>
    <div class="alert alert-danger">
      <strong>Run the schema first.</strong>
      <div class="mt-2">
        Missing table<?php echo count($missingTables) === 1 ? '' : 's'; ?>:
        <?php foreach ($missingTables as $t): ?><code><?php echo h($t); ?></code> <?php endforeach; ?>
      </div>
      <div class="mt-3 small">
        In phpMyAdmin: select <code>secuscan_db</code> &rarr; SQL tab &rarr; paste
        <code>threatmap_setup.sql</code> &rarr; Go. Then reload this page.
      </div>
    </div>
  <?php endif; ?>

  <?php if ($message !== ''): ?>
    <div class="alert <?php echo $done ? 'alert-success' : 'alert-info'; ?>"><?php echo h($message); ?></div>
  <?php endif; ?>

  <div class="card p-4 mb-4">
    <h2 class="h6 fw-bold mb-3">Database tables</h2>
    <?php foreach (['geoip_country', 'geoip_block'] as $t): ?>
      <div class="d-flex justify-content-between border-bottom py-2">
        <code><?php echo h($t); ?></code>
        <span class="badge <?php echo in_array($t, $missingTables, true) ? 'text-bg-danger' : 'text-bg-success'; ?>">
          <?php echo in_array($t, $missingTables, true) ? 'missing' : 'present'; ?></span>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="card p-4 mb-4">
    <h2 class="h6 fw-bold mb-3">Current state</h2>
    <div class="d-flex justify-content-between border-bottom py-2">
      <span>Countries</span><strong><?php echo number_format($stats['countries']); ?></strong>
    </div>
    <div class="d-flex justify-content-between py-2">
      <span>IP blocks</span><strong><?php echo number_format($stats['blocks']); ?></strong>
    </div>
  </div>

  <div class="card p-4 mb-4">
    <h2 class="h6 fw-bold mb-3">CSV files</h2>
    <div class="d-flex justify-content-between border-bottom py-2">
      <code>GeoLite2-Country-Locations-en.csv</code>
      <span class="badge <?php echo is_readable(LOCATIONS_CSV)?'text-bg-success':'text-bg-danger'; ?>">
        <?php echo is_readable(LOCATIONS_CSV) ? 'found' : 'missing'; ?></span>
    </div>
    <div class="d-flex justify-content-between py-2">
      <code>GeoLite2-Country-Blocks-IPv4.csv</code>
      <span class="badge <?php echo is_readable(BLOCKS_CSV)?'text-bg-success':'text-bg-danger'; ?>">
        <?php echo is_readable(BLOCKS_CSV) ? 'found' : 'missing'; ?></span>
    </div>
    <?php if (!$filesReady): ?>
      <p class="small text-secondary mt-3 mb-0">
        Put both files in the same folder as this script, then reload.
      </p>
    <?php endif; ?>
  </div>

  <?php if ($filesReady && $schemaReady): ?>
    <div class="card p-4">
      <h2 class="h6 fw-bold mb-3">Run the import — in this order</h2>
      <a href="import_geolite.php?action=locations" class="btn btn-primary mb-2 w-100">
        Step 1 — import countries (fast)
      </a>
      <a href="import_geolite.php?action=blocks&offset=0" class="btn btn-primary w-100">
        Step 2 — import IP blocks (a few minutes; the page refreshes itself)
      </a>
      <?php if (is_readable(BLOCKS_CSV)): ?>
        <div class="small text-secondary mt-2">
          File holds roughly <?php echo number_format((int) (filesize(BLOCKS_CSV) / 38)); ?> rows
          (<?php echo number_format(filesize(BLOCKS_CSV) / 1048576, 1); ?> MB).
        </div>
      <?php endif; ?>
      <p class="small text-secondary mt-3 mb-0">
        Step 2 runs in batches of <?php echo number_format(BATCH_ROWS); ?> rows and reloads until it finishes,
        resuming from a byte offset so later batches are no slower than the first.
        Leave the tab open. Re-running either step is safe — it replaces the table.
      </p>
    </div>
  <?php endif; ?>

  <p class="text-center small text-secondary mt-4">
    This product includes GeoLite2 data created by MaxMind, available from
    <a href="https://www.maxmind.com" class="text-info">maxmind.com</a>.
    <span class="d-block mt-2">Delete this file once the import is complete.</span>
  </p>
</div>
</body>
</html>
