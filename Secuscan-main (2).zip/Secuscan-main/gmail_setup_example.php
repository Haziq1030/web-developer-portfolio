<?php
// Example configuration for Gmail SMTP email verification.
// Put these in your Apache environment or php.ini before testing.
//
// setenv SECUSCAN_GMAIL_USER your-email@gmail.com
// setenv SECUSCAN_GMAIL_APP_PASSWORD your-16-character-app-password
// setenv SECUSCAN_FROM_EMAIL your-email@gmail.com
//
// Or define them temporarily in PHP before calling register.php:
// putenv('SECUSCAN_GMAIL_USER=your-email@gmail.com');
// putenv('SECUSCAN_GMAIL_APP_PASSWORD=your-app-password');
// putenv('SECUSCAN_FROM_EMAIL=your-email@gmail.com');

phpinfo(INFO_GENERAL);
