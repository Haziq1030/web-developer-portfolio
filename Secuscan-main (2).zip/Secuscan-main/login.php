<?php
session_start();
$conn = new mysqli("localhost", "root", "", "secuscan_db");
$error = "";

$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified TINYINT(1) NOT NULL DEFAULT 0");
$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS verification_token VARCHAR(255) NULL");

if (isset($_POST['login'])) {
    $login_input = trim($_POST['login_input']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
    $stmt->bind_param("ss", $login_input, $login_input);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($user = $res->fetch_assoc()) {
        $isAdmin = (int) ($user['is_admin'] ?? 0) === 1;

        if (!$isAdmin && (int) $user['email_verified'] !== 1) {
            $error = "Please verify your email first before logging in.";
        } elseif (password_verify($password, $user['password']) || md5($password) === $user['password']) {
            session_regenerate_id(true);
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['is_admin'] = $isAdmin;

            if ($isAdmin) {
                header("Location: admin.php");
            } else {
                header("Location: index.php");
            }
            exit();
        } else {
            $error = "Invalid Username / Email or Password!";
        }
    } else {
        $error = "Invalid Username / Email or Password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - SecuScan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        * { box-sizing: border-box; }
        body { background:linear-gradient(135deg,#f8fbff 0%,#eef4ff 52%,#f1f5f9 100%); color:#0f172a; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; padding:24px; font-family:'Plus Jakarta Sans',sans-serif; overflow:hidden; }
        body:before,body:after{content:'';position:fixed;width:300px;height:300px;border-radius:50%;filter:blur(75px);pointer-events:none;opacity:.35}body:before{top:-140px;left:-100px;background:rgba(96,165,250,.3)}body:after{right:-100px;bottom:-160px;background:rgba(147,197,253,.45)}
        .login-card { position:relative;z-index:1;background:rgba(255,255,255,.94);backdrop-filter:blur(15px);-webkit-backdrop-filter:blur(15px);border:1px solid rgba(148,163,184,.25);border-radius:16px;box-shadow:0 20px 50px rgba(15,23,42,.08);width:100%;max-width:420px;padding:2.5rem; }
        .brand-icon{width:64px;height:64px;display:grid;place-items:center;margin:0 auto 1.25rem;color:#2563eb;border:1px solid rgba(37,99,235,.18);border-radius:18px;background:rgba(37,99,235,.05);box-shadow:inset 0 0 18px rgba(37,99,235,.04)}.brand-title{color:#0f172a;font-family:'Orbitron',sans-serif;font-size:1.25rem;letter-spacing:.04em}.brand-subtitle{color:#64748b;font-size:.84rem}.form-label{color:#334155;font-size:.85rem;font-weight:700}
        .form-control { background:rgba(255,255,255,.9);border:1px solid #cbd5e1;color:#0f172a;min-height:48px;border-radius:8px }.form-control::placeholder{color:#94a3b8}.form-control:focus{background:#fff;border-color:#60a5fa;box-shadow:0 0 0 3px rgba(96,165,250,.12);color:#0f172a}
        .btn-cyber{background:linear-gradient(135deg,#2563eb 0%,#3b82f6 100%);border:none;color:#fff;font-weight:700;width:100%;padding:12px;border-radius:8px;box-shadow:0 10px 22px rgba(37,99,235,.18);transition:transform .2s ease,box-shadow .2s ease,filter .2s ease}.btn-cyber:hover{color:#fff;transform:translateY(-2px);filter:brightness(1.02);box-shadow:0 14px 28px rgba(37,99,235,.2)}.btn-cyber:active{transform:translateY(1px) scale(.98)}.login-card a{color:#2563eb;font-weight:700;text-decoration:none}.login-card a:hover{color:#1d4ed8}.login-card .alert{background:rgba(255,255,255,.92);color:#1e293b;border-radius:10px}.login-card .alert-danger{border-color:rgba(239,68,68,.2)}
        @media(max-width:480px){.login-card{padding:2rem 1.35rem}}
    </style>
</head>
<body>
    <div class="login-card">
        <div class="brand-icon"><i class="fa-solid fa-shield-halved fa-2x"></i></div>
        <h1 class="brand-title text-center mb-2">SecuScan</h1>
        <p class="brand-subtitle text-center mb-4">Portal Security Access</p>
        <?php if ($error): ?><div class="alert alert-danger mb-4" role="alert"><i class="fa-solid fa-triangle-exclamation me-2"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label" for="login_input">Username or Email</label>
                <input type="text" id="login_input" name="login_input" class="form-control" autocomplete="username" required>
            </div>
            <div class="mb-4">
                <label class="form-label" for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" autocomplete="current-password" required>
            </div>
            <button type="submit" name="login" class="btn btn-cyber w-100 mb-3"><i class="fa-solid fa-arrow-right-to-bracket me-2"></i>Login Securely</button>
            <p class="text-center brand-subtitle mb-0">Don't have an account? <a href="register.php">Create Account</a></p>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>