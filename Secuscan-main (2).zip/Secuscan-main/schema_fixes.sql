-- =====================================================================
-- SecuScan — STEP 2 of 2 (OPTIONAL): fixes from the code review.
--
-- Run this AFTER api_setup.sql, and only once the new pages work.
-- Unlike step 1, these statements modify EXISTING tables, so run them
-- one block at a time and read the result of each.
--
-- Back up first:  mysqldump -u root secuscan_db > backup.sql
-- =====================================================================

USE secuscan_db;

-- ---------------------------------------------------------------------
-- FIX 1 — Missing indexes
-- Every dashboard query filters on user_id. Without an index MySQL scans
-- the whole table each time.
--
-- Note: "ADD INDEX IF NOT EXISTS" is MariaDB syntax. Your server is
-- MariaDB 10.4, so this works. On stock MySQL, drop the IF NOT EXISTS
-- and just accept a "Duplicate key name" error if it already exists.
-- ---------------------------------------------------------------------
ALTER TABLE scan_logs      ADD INDEX IF NOT EXISTS idx_scan_user (user_id);
ALTER TABLE file_scan_logs ADD INDEX IF NOT EXISTS idx_file_user (user_id);

-- ---------------------------------------------------------------------
-- FIX 2 — url column truncates long phishing URLs
-- Phishing URLs routinely exceed 255 characters. VARCHAR(255) silently
-- cuts them off, which corrupts the evidence you are storing.
-- ---------------------------------------------------------------------
ALTER TABLE scan_logs MODIFY COLUMN url TEXT NOT NULL;

-- ---------------------------------------------------------------------
-- FIX 3 — One corrupted row
-- Row id 4 of file_scan_logs has a Windows filesystem path written into
-- the file_hash column instead of a digest. Check what will be removed
-- BEFORE deleting:
-- ---------------------------------------------------------------------
SELECT id, filename, file_hash
FROM file_scan_logs
WHERE file_hash NOT REGEXP '^[a-f0-9]{64}$';

-- Once you have looked at that list and are happy, run:
-- DELETE FROM file_scan_logs WHERE file_hash NOT REGEXP '^[a-f0-9]{64}$';

-- ---------------------------------------------------------------------
-- FIX 4 — The admin password (DO THIS ONE)
-- The admin row currently holds 0192023a7bbd73250516f069df18b500, which
-- is the MD5 of "admin123" — crackable from any rainbow table in about
-- one second.
--
-- Generate a proper bcrypt hash first, in a terminal:
--
--   C:\xamppb\php\php.exe -r "echo password_hash('YourNewPassword', PASSWORD_DEFAULT);"
--
-- Paste the output (it starts with $2y$) between the quotes below and
-- uncomment the line:
--
-- UPDATE users SET password = 'PASTE_THE_$2y$_HASH_HERE' WHERE username = 'admin';
--
-- Then open login.php and DELETE this from line 23:
--     || md5($password) === $user['password']
-- Leaving it in means the weak hash still works and this fix achieves
-- nothing.
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- Verify the indexes landed
-- ---------------------------------------------------------------------
SHOW INDEX FROM scan_logs WHERE Key_name = 'idx_scan_user';
SHOW INDEX FROM file_scan_logs WHERE Key_name = 'idx_file_user';
