-- =====================================================================
-- SecuScan — STEP 1 of 2: create the four new tables.
--
-- Run this FIRST. It only creates new tables and touches nothing you
-- already have, so it cannot break existing data.
--
-- phpMyAdmin:  select secuscan_db  ->  SQL tab  ->  paste  ->  Go
-- Command line: mysql -u root secuscan_db < api_setup.sql
--
-- Safe to re-run: every statement is IF NOT EXISTS.
-- =====================================================================

USE secuscan_db;

-- ---------------------------------------------------------------------
-- 1. Provider response cache
--    The UNIQUE key on (provider, cache_key) is what makes the
--    ON DUPLICATE KEY UPDATE in ApiCache::put() work. Do not drop it.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_cache (
    id            INT NOT NULL AUTO_INCREMENT,
    provider      VARCHAR(32)  NOT NULL,
    cache_key     VARCHAR(191) NOT NULL,
    response_json LONGTEXT     NOT NULL,
    http_code     SMALLINT     NOT NULL DEFAULT 200,
    fetched_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_provider_key (provider, cache_key),
    KEY idx_fetched_at (fetched_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- 2. Client-side rate-limit ledger
--    One row per outbound API call, so we can refuse politely instead
--    of burning a request to be told 429.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_rate_log (
    id        INT NOT NULL AUTO_INCREMENT,
    provider  VARCHAR(32) NOT NULL,
    called_at TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_provider_time (provider, called_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- 3. Hash scan history
--    verdict is an ENUM so an invalid state cannot be written, and
--    'unknown' is a first-class value rather than being silently
--    recorded as safe.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hash_scan_logs (
    id            INT NOT NULL AUTO_INCREMENT,
    user_id       INT          DEFAULT NULL,
    file_hash     VARCHAR(64)  NOT NULL,
    filename      VARCHAR(255) NOT NULL DEFAULT '',
    file_size     BIGINT       NOT NULL DEFAULT 0,
    verdict       ENUM('malicious','suspicious','clean','unknown','error') NOT NULL DEFAULT 'unknown',
    provider_json TEXT         NULL,
    scanned_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_hash_user (user_id),
    KEY idx_hash_value (file_hash),
    KEY idx_hash_verdict (verdict)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- 4. IP scan history
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ip_scan_logs (
    id            INT NOT NULL AUTO_INCREMENT,
    user_id       INT         DEFAULT NULL,
    ip_address    VARCHAR(45) NOT NULL,          -- 45 chars fits a full IPv6
    verdict       ENUM('malicious','suspicious','clean','unknown','error') NOT NULL DEFAULT 'unknown',
    abuse_score   TINYINT UNSIGNED NOT NULL DEFAULT 0,
    total_reports INT         NOT NULL DEFAULT 0,
    country_code  VARCHAR(2)  NOT NULL DEFAULT '',
    isp           VARCHAR(150) NOT NULL DEFAULT '',
    usage_type    VARCHAR(80)  NOT NULL DEFAULT '',
    scanned_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_ip_user (user_id),
    KEY idx_ip_value (ip_address),
    KEY idx_ip_verdict (verdict)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Verify: all four rows must come back, each with a count of 0.
-- ---------------------------------------------------------------------
SELECT 'api_cache' AS table_name, COUNT(*) AS rows_present FROM api_cache
UNION ALL SELECT 'api_rate_log',   COUNT(*) FROM api_rate_log
UNION ALL SELECT 'hash_scan_logs', COUNT(*) FROM hash_scan_logs
UNION ALL SELECT 'ip_scan_logs',   COUNT(*) FROM ip_scan_logs;
