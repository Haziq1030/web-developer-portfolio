<?php
/**
 * SecuScan — raw AI endpoint probe.
 *
 * Standalone on purpose: it does NOT use the service classes, so it works even
 * if a file did not get replaced, and its result cannot be explained away by a
 * bug in my wrapper code. It shows the real HTTP status and the real response
 * body for every endpoint worth trying, across all three vendors.
 *
 * Open it, screenshot the output, and the answer is in there.
 *
 * DELETE THIS FILE once the assistant works.
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '1');
@set_time_limit(180);
session_start();

require_once __DIR__ . '/config.php';

// Same admin gate as api_test.php. Comment out these four lines if you have
// not logged in as admin yet.
if (empty($_SESSION['user_id']) || empty($_SESSION['is_admin'])) {
    http_response_code(403);
    exit('Administrator login required. Comment out the gate at the top of ai_debug.php if you are still setting up.');
}

function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }

$KEY = secuscan_key('AI_ASSIST_API_KEY');

/** Raw request. No wrapper classes, no abstractions. */
function probe(string $method, string $url, array $headers, ?string $body): array
{
    $ch = curl_init();
    $lines = [];
    foreach ($headers as $k => $v) { $lines[] = $k . ': ' . $v; }

    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => $lines,
        CURLOPT_TIMEOUT        => 25,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    if (CA_BUNDLE_PATH !== '' && is_file(CA_BUNDLE_PATH)) {
        curl_setopt($ch, CURLOPT_CAINFO, CA_BUNDLE_PATH);
    }
    if ($body !== null) { curl_setopt($ch, CURLOPT_POSTFIELDS, $body); }

    $raw  = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    return ['code' => $code, 'body' => $raw === false ? '' : (string) $raw, 'curl_error' => $err];
}

/** Pull the human-readable message out of whatever error shape came back. */
function errMessage(string $body): string
{
    $j = json_decode($body, true);
    if (!is_array($j)) { return ''; }
    return (string) ($j['error']['message']
        ?? $j['error']['messages'][0]
        ?? (is_string($j['error'] ?? null) ? $j['error'] : '')
        ?? '');
}

$prompt = 'Reply with exactly: OK';
$tests = [];

// -------------------------------------------------------------------------
// A. Google Gemini — is the key even accepted, and what can it see?
// -------------------------------------------------------------------------
foreach (['v1beta', 'v1'] as $ver) {
    $tests[] = [
        'group' => 'Google Gemini',
        'name'  => "ListModels ($ver) — key in header",
        'run'   => fn() => probe('GET', "https://generativelanguage.googleapis.com/$ver/models?pageSize=200",
                    ['x-goog-api-key' => $GLOBALS['KEY'], 'Accept' => 'application/json'], null),
    ];
    $tests[] = [
        'group' => 'Google Gemini',
        'name'  => "ListModels ($ver) — key in query string",
        'run'   => fn() => probe('GET', "https://generativelanguage.googleapis.com/$ver/models?pageSize=200&key=" . urlencode($GLOBALS['KEY']),
                    ['Accept' => 'application/json'], null),
    ];
}
$tests[] = [
    'group' => 'Google Gemini',
    'name'  => 'ListModels (v1beta) — OAuth Bearer',
    'run'   => fn() => probe('GET', 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200',
                ['Authorization' => 'Bearer ' . $GLOBALS['KEY'], 'Accept' => 'application/json'], null),
];

$geminiBody = json_encode([
    'contents' => [['role' => 'user', 'parts' => [['text' => $prompt]]]],
    'generationConfig' => ['maxOutputTokens' => 20],
]);
foreach (['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-flash-latest'] as $m) {
    $tests[] = [
        'group' => 'Google Gemini',
        'name'  => "generateContent — $m",
        'run'   => fn() => probe('POST', "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                    ['Content-Type' => 'application/json', 'x-goog-api-key' => $GLOBALS['KEY']], $GLOBALS['geminiBody']),
    ];
}

// -------------------------------------------------------------------------
// B. OpenAI
// -------------------------------------------------------------------------
$tests[] = [
    'group' => 'OpenAI',
    'name'  => 'GET /v1/models',
    'run'   => fn() => probe('GET', 'https://api.openai.com/v1/models',
                ['Authorization' => 'Bearer ' . $GLOBALS['KEY']], null),
];

// -------------------------------------------------------------------------
// C. Groq
// -------------------------------------------------------------------------
$tests[] = [
    'group' => 'Groq',
    'name'  => 'GET /openai/v1/models',
    'run'   => fn() => probe('GET', 'https://api.groq.com/openai/v1/models',
                ['Authorization' => 'Bearer ' . $GLOBALS['KEY']], null),
];

// -------------------------------------------------------------------------
// D. Control — proves the network and TLS path itself is fine
// -------------------------------------------------------------------------
$tests[] = [
    'group' => 'Control',
    'name'  => 'Plain HTTPS reachability (no key)',
    'run'   => fn() => probe('GET', 'https://www.google.com/generate_204', [], null),
];

$results = [];
foreach ($tests as $t) {
    $r = ($t['run'])();
    $results[] = $t + $r;
}

/** Which of the vendor probes actually succeeded? */
$winners = array_values(array_filter($results, static fn($r) =>
    $r['group'] !== 'Control' && $r['code'] >= 200 && $r['code'] < 300));
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SecuScan AI Probe</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{background:linear-gradient(135deg,#f8fbff 0%,#eef4ff 45%,#f1f5f9 100%);color:#0f172a;padding:28px 16px;font-size:.92rem}
    .card{background:rgba(255,255,255,.96);border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 18px 42px rgba(15,23,42,.05)}
    pre{background:#f8fafc;color:#1e293b;padding:10px;border-radius:8px;font-size:.74rem;max-height:190px;overflow:auto;white-space:pre-wrap;word-break:break-all;border:1px solid #e2e8f0}
    code{color:#2563eb}
    .mono{font-family:ui-monospace,Menlo,Consolas,monospace}
  </style>
</head>
<body>
<div class="container" style="max-width:920px">

  <h1 class="fw-bold mb-1">AI endpoint probe</h1>
  <p class="text-secondary">
    Key in use: <span class="mono"><?php
      echo h(strlen($KEY) > 12 ? substr($KEY, 0, 8) . str_repeat('*', 8) . substr($KEY, -4) : '(not set)');
    ?></span>
    &middot; length <?php echo strlen($KEY); ?>
    &middot; config says <code><?php echo h(AI_PROVIDER); ?></code>
  </p>

  <?php if (!empty($winners)): ?>
    <div class="card p-4 mb-4" style="border-color:rgba(34,197,94,.5)">
      <h2 class="h5 fw-bold text-success mb-2">Found a working endpoint</h2>
      <p class="mb-2">These probes returned success — the key belongs to whichever vendor is named here:</p>
      <ul class="mb-2">
        <?php foreach ($winners as $w): ?>
          <li><strong><?php echo h($w['group']); ?></strong> — <?php echo h($w['name']); ?> (HTTP <?php echo $w['code']; ?>)</li>
        <?php endforeach; ?>
      </ul>
      <p class="mb-0 small text-secondary">
        Set <code>AI_PROVIDER</code> in config.php to match that vendor
        (<code>gemini</code>, <code>openai</code> or <code>groq</code>), then reload the AI Assist page.
      </p>
    </div>
  <?php else: ?>
    <div class="card p-4 mb-4" style="border-color:rgba(239,68,68,.5)">
      <h2 class="h5 fw-bold text-danger mb-2">No vendor accepted this key</h2>
      <p class="mb-0 small">
        Read the response bodies below. If every vendor says the key is invalid, the key
        needs to be reissued. If the Control probe at the bottom also failed, the problem is
        the network or the certificate bundle, not the key.
      </p>
    </div>
  <?php endif; ?>

  <?php
    $lastGroup = '';
    foreach ($results as $r):
      if ($r['group'] !== $lastGroup) {
          if ($lastGroup !== '') { echo '</div>'; }
          echo '<div class="card p-4 mb-3"><h2 class="h6 fw-bold mb-3">' . h($r['group']) . '</h2>';
          $lastGroup = $r['group'];
      }
      $ok = $r['code'] >= 200 && $r['code'] < 300;
      $msg = errMessage($r['body']);
  ?>
    <div class="border-top pt-3 mt-3">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
        <span class="mono small"><?php echo h($r['name']); ?></span>
        <span class="badge <?php echo $ok ? 'text-bg-success' : ($r['code'] === 0 ? 'text-bg-dark' : 'text-bg-danger'); ?> rounded-pill">
          <?php echo $r['code'] === 0 ? 'NO RESPONSE' : 'HTTP ' . $r['code']; ?>
        </span>
      </div>
      <?php if ($r['curl_error'] !== ''): ?>
        <div class="alert alert-dark small py-2 mb-2">cURL: <?php echo h($r['curl_error']); ?></div>
      <?php endif; ?>
      <?php if ($msg !== ''): ?>
        <div class="small text-warning mb-2">&rarr; <?php echo h($msg); ?></div>
      <?php endif; ?>
      <?php if ($r['body'] !== ''): ?>
        <pre><?php echo h(mb_substr($r['body'], 0, 1200)); ?><?php echo mb_strlen($r['body']) > 1200 ? "\n… truncated" : ''; ?></pre>
      <?php endif; ?>
    </div>
  <?php endforeach; if ($lastGroup !== '') { echo '</div>'; } ?>

  <p class="text-center text-secondary small mt-4">
    Delete this file once the assistant works.
    <a href="api_test.php" class="ms-2">Back to diagnostics</a>
  </p>
</div>
</body>
</html>
