<?php
session_start();
$conn = new mysqli("localhost", "root", "", "secuscan_db");
$msg = "";
$lastVerificationLink = "";
$appPath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');

// ============================
// GMAIL SMTP CONFIGURATION
// ============================
// Replace these values with your real Gmail + App Password before testing.
// You can also set these in Apache environment variables.
putenv('SECUSCAN_GMAIL_USER=your-email@gmail.com');
putenv('SECUSCAN_GMAIL_APP_PASSWORD=your-16-char-app-password');
putenv('SECUSCAN_FROM_EMAIL=your-email@gmail.com');

require_once __DIR__ . '/vendor/PHPMailer-6.9.2/src/Exception.php';
require_once __DIR__ . '/vendor/PHPMailer-6.9.2/src/PHPMailer.php';
require_once __DIR__ . '/vendor/PHPMailer-6.9.2/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified TINYINT(1) NOT NULL DEFAULT 0");
$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS verification_token VARCHAR(255) NULL");

function sendVerificationEmail($toEmail, $username, $verificationToken) {
    $smtpUser = getenv('SECUSCAN_GMAIL_USER') ?: getenv('GMAIL_USER');
    $smtpPass = getenv('SECUSCAN_GMAIL_APP_PASSWORD') ?: getenv('GMAIL_APP_PASSWORD');
    $fromEmail = getenv('SECUSCAN_FROM_EMAIL') ?: ($smtpUser ?: 'no-reply@secuscan.local');
    $appPath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');

    $verifyLink = "http://" . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $appPath . "/verify_email.php?token=" . urlencode($verificationToken);

    if (empty($smtpUser) || empty($smtpPass) || $smtpUser === 'your-email@gmail.com') {
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = $smtpUser;
        $mail->Password = $smtpPass;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;
        $mail->CharSet = 'UTF-8';

        $mail->setFrom($fromEmail, 'SecuScan');
        $mail->addAddress($toEmail, $username);
        $mail->Subject = 'Verify your SecuScan account';
        $mail->Body = "Hello {$username},\r\n\r\nPlease verify your email by clicking the link below:\r\n{$verifyLink}\r\n\r\nThank you.\r\nSecuScan Team";
        $mail->AltBody = "Hello {$username}, please verify your email: {$verifyLink}";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($username) || empty($email) || empty($password)) {
        $msg = "<div class='alert alert-danger'>Please fill in all required fields.</div>";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->bind_param("ss", $username, $email);
        $check->execute();

        if ($check->get_result()->num_rows > 0) {
            $msg = "<div class='alert alert-danger'>Username or Email already exists!</div>";
        } else {
            $token = bin2hex(random_bytes(32));
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO users (username, email, password, is_admin, email_verified, verification_token) VALUES (?, ?, ?, 0, 0, ?)");
            $stmt->bind_param("ssss", $username, $email, $hashedPassword, $token);

            if ($stmt->execute()) {
                $verifyLink = "http://" . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $appPath . "/verify_email.php?token=" . urlencode($token);
                $emailSent = sendVerificationEmail($email, $username, $token);

                if ($emailSent) {
                    $msg = "<div class='alert alert-success'>Registration successful! Please check your Gmail inbox and verify your account before login.</div>";
                } else {
                    $lastVerificationLink = $verifyLink;
                    $msg = "<div class='alert alert-warning'>Gmail SMTP is not configured yet. Please replace the sample Gmail credentials in register.php with your real Gmail and App Password.</div>";
                }
            } else {
                $msg = "<div class='alert alert-danger'>Registration failed. Please try again.</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up - SecuScan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
        <style>
            body.auth-page { background: linear-gradient(135deg, #f8fbff 0%, #eef4ff 46%, #f1f5f9 100%) !important; color: #0f172a !important; }
            body.auth-page .auth-card { background: rgba(255, 255, 255, .96) !important; border: 1px solid #dbeafe !important; box-shadow: 0 20px 60px rgba(15, 23, 42, .09) !important; }
            body.auth-page .auth-title, body.auth-page .form-label { color: #0f172a !important; }
            body.auth-page .auth-subtitle, body.auth-page .text-muted { color: #64748b !important; }
            body.auth-page .custom-input { background: #fff !important; color: #0f172a !important; border-color: #cbd5e1 !important; }
            body.auth-page .custom-input::placeholder { color: #94a3b8 !important; }
            body.auth-page .alert { background: #fff !important; color: #1e293b !important; }
            body.auth-page a { color: #2563eb !important; }
            .verify-link-box {
                margin-top: 8px;
                margin-bottom: 14px;
                padding: 10px 12px;
                border: 1px solid rgba(59, 130, 246, .15);
                background: linear-gradient(135deg, #eef6ff, #fff7ed);
                border-radius: 12px;
                text-align: center;
                box-shadow: 0 8px 20px rgba(59, 130, 246, .08);
            }
            .verify-email-link {
                display: inline-block;
                width: 100%;
                padding: 12px 16px;
                border-radius: 10px;
                font-weight: 800;
                letter-spacing: .02em;
                color: #ffffff !important;
                text-decoration: none !important;
                background: linear-gradient(135deg, #ff5f6d, #ffc371, #4facfe, #00c6ff);
                background-size: 220% 220%;
                box-shadow: 0 8px 18px rgba(79, 172, 254, .25);
                animation: verifyBlink 0.6s ease-in-out infinite alternate;
            }
            @keyframes verifyBlink {
                0% { opacity: 1; transform: scale(1); background-position: 0% 50%; }
                100% { opacity: .8; transform: scale(1.02); background-position: 100% 50%; }
            }
        </style>
</head>
<body class="auth-page d-flex align-items-center justify-content-center p-3">
    <div class="card auth-card style-box">
        <div class="auth-brand-icon"><i class="fa-solid fa-shield-halved fa-2x"></i></div>
        <h3 class="auth-title text-center mb-1">Create Account</h3>
        <p class="auth-subtitle text-center mb-4">SecuScan | Portal Security Access</p>
        <?= $msg ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label font-weight-bold">Username</label>
                <input type="text" name="username" class="form-control custom-input" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control custom-input" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control custom-input" required>
            </div>
            <?php if (!empty($lastVerificationLink)): ?>
                <div class="verify-link-box">
                    <a href="<?= htmlspecialchars($lastVerificationLink, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener" class="verify-email-link">
                        Verify Email
                    </a>
                </div>
            <?php endif; ?>
            <small class="text-muted d-block mb-3">Use a real Gmail address and an App Password for email verification.</small>
            <button type="submit" name="register" class="btn btn-cyber w-100 mb-3"><i class="fa-solid fa-user-plus me-2"></i>Create Secure Account</button>
            <p class="text-center text-muted mb-0">Already have an account? <a href="login.php">Sign In</a></p>
        </form>
    </div>
</body>
</html>