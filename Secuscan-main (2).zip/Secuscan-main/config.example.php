<?php
/**
 * Template for config.php. THIS file is safe to commit; config.php is not.
 *
 * Setup:
 *   1. cp config.example.php config.php
 *   2. Fill in the four values marked REPLACE_ME
 *   3. Confirm config.php is listed in .gitignore
 *
 * Get free API keys from:
 *   VirusTotal   https://www.virustotal.com/gui/my-apikey
 *   AbuseIPDB    https://www.abuseipdb.com/account/api
 *   MetaDefender https://www.opswat.com/developers  (MetaDefender Cloud)
 */

const DB_HOST = 'localhost';
const DB_USER = 'root';
const DB_PASS = '';            // REPLACE_ME — do not ship an empty root password
const DB_NAME = 'secuscan_db';

const VIRUSTOTAL_API_KEY   = 'REPLACE_ME';
const ABUSEIPDB_API_KEY    = 'REPLACE_ME';
const METADEFENDER_API_KEY = 'REPLACE_ME';

// The rest of this file is identical to config.php — copy it across.
// See config.php for RATE_LIMITS, CACHE_TTL, HTTP_TIMEOUT, CA_BUNDLE_PATH,
// NEWS_FEEDS, secuscan_key() and secuscan_db().
