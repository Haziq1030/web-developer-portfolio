-- =====================================================================
-- SecuScan — AI Assist table.
--
-- Run AFTER api_setup.sql. Creates one new table, touches nothing else.
-- phpMyAdmin: select secuscan_db -> SQL tab -> paste -> Go
-- =====================================================================

USE secuscan_db;

-- ---------------------------------------------------------------------
-- Conversation log.
--
-- Two jobs: staff oversight of how the assistant is being used, and the
-- per-student hourly counter (a COUNT over the last hour IS the limit,
-- so there is no separate counter to drift out of sync).
--
-- Note for the privacy notice you give students: this table records the
-- questions they type. Tell them that plainly, and keep the retention
-- job at the bottom of this file running so it does not accumulate
-- forever.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ai_chat_logs (
    id           INT NOT NULL AUTO_INCREMENT,
    user_id      INT      DEFAULT NULL,
    question     TEXT     NOT NULL,
    reply        TEXT     NULL,
    was_answered TINYINT(1) NOT NULL DEFAULT 0,
    created_at   TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    -- This composite index is what makes the hourly rate-limit query fast.
    KEY idx_ai_user_time (user_id, created_at),
    KEY idx_ai_answered (was_answered)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ---------------------------------------------------------------------
-- Verify
-- ---------------------------------------------------------------------
SELECT 'ai_chat_logs' AS table_name, COUNT(*) AS rows_present FROM ai_chat_logs;

-- ---------------------------------------------------------------------
-- Retention (recommended)
-- Chat logs are student writing. Keeping them forever serves no purpose
-- and grows your exposure if the database is ever compromised. Run this
-- periodically, or add it to a scheduled task:
--
--   DELETE FROM ai_chat_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);
-- ---------------------------------------------------------------------
