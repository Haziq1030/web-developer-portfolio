<?php
session_start();
ob_start(function ($output) {
    return strtr($output, [
        'Rekod ' => 'Records ',
        'semua pengguna' => 'all users',
        'akaun anda' => 'your account',
        'Ringkasan keselamatan' => 'Security summary',
        'Nisbah rekod bersih berbanding ancaman' => 'Ratio of safe records to threats',
        'Semak pautan meragukan dan hash fail sebelum berkongsi atau membukanya.' => 'Check suspicious links and file hashes before sharing or opening them.',
        'Mula Scan' => 'Start Scan',
        'Sejarah scan terkini' => 'Recent scan history',
        '8 rekod paling baharu' => '8 latest records',
        'Scan baharu' => 'New scan',
        'Jenis' => 'Type',
        'Keputusan' => 'Result',
        'Masa' => 'Time',
        'Belum ada rekod scan.' => 'No scan records yet.',
        'Aduan pengguna' => 'User complaints',
        'Admin boleh mengurus aduan terus dari dashboard ini.' => 'Administrators can manage complaints directly from this dashboard.',
        'baharu' => 'new',
        'Pengguna' => 'User',
        'Kategori' => 'Category',
        'Mesej' => 'Message',
        'Tarikh' => 'Date',
        'Belum ada aduan.' => 'No complaints yet.',
        'Semak pautan sebelum klik' => 'Check a link before clicking',
        'Imbas fail dengan selamat' => 'Scan files safely',
        'Gunakan AI Engine SecuScan untuk mengenal pasti ciri phishing pada URL.' => 'Use the SecuScan AI Engine to identify phishing characteristics in a URL.',
        'SecuScan hanya menghantar hash SHA-256 kepada enjin semakan, bukan kandungan fail mentah.' => 'SecuScan sends only the SHA-256 hash to the scanning engine, not the raw file contents.',
        'Tujuan Semakan' => 'Scan Purpose',
        'Pilih tujuan' => 'Select a purpose',
        'Pelajaran / Education' => 'Education',
        'Kerja / Work' => 'Work',
        'Semakan Peribadi / Personal Check' => 'Others',
        'Pengujian / Testing' => 'Shopping',
        'URL yang ingin disemak' => 'URL to scan',
        'Pilih fail' => 'Choose a file',
        'Berhenti. Semak. Lindungi.' => 'Stop. Check. Protect.',
        'Tabiat kecil seperti menyemak domain dan tidak berkongsi OTP boleh mengurangkan risiko serangan dengan ketara.' => 'Small habits such as checking domains and never sharing OTPs can significantly reduce attack risks.',
        'Kenal pasti phishing' => 'Identify phishing',
        'Semak ejaan domain, URL yang terlalu mendesak, dan permintaan login atau OTP yang mencurigakan.' => 'Check domain spelling, overly urgent URLs, and suspicious login or OTP requests.',
        'Lindungi akaun' => 'Protect your account',
        'Gunakan kata laluan unik, pengesahan dua faktor, dan jangan kongsi kod keselamatan.' => 'Use unique passwords, two-factor authentication, and never share security codes.',
        'Sentiasa dikemas kini' => 'Stay up to date',
        'Kemas kini sistem dan aplikasi. Laporkan mesej mencurigakan kepada organisasi berkaitan.' => 'Keep systems and applications updated. Report suspicious messages to the relevant organization.',
        'Ancaman lazim semasa: pautan login palsu, lampiran malware, dan mesej yang mendesak pengguna bertindak segera. Jangan klik dahulu, semak dengan SecuScan.' => 'Common threats include fake login links, malware attachments, and messages urging immediate action. Check with SecuScan before clicking.',
        'Kami sedia membantu' => 'We are here to help',
        'Hubungi pasukan SecuScan untuk bantuan teknikal, pertanyaan akaun, atau panduan menggunakan sistem.' => 'Contact the SecuScan team for technical support, account questions, or guidance on using the system.',
        'E-mel sokongan' => 'Support email',
        'Waktu operasi' => 'Operating hours',
        'Isnin - Jumaat, 9:00 pagi - 5:00 petang' => 'Monday - Friday, 9:00 AM - 5:00 PM',
        'Perlu laporkan isu?' => 'Need to report an issue?',
        'Hantar butiran isu melalui borang aduan supaya pasukan kami boleh menyiasatnya.' => 'Send the issue details through the complaint form so our team can investigate.',
        'Buka borang aduan' => 'Open complaint form',
        'Hantar aduan atau maklum balas' => 'Submit a complaint or feedback',
        'Bantu kami menjadikan SecuScan lebih baik. Semua medan bertanda diperlukan.' => 'Help us improve SecuScan. All marked fields are required.',
        'Nama' => 'Name',
        'E-mel' => 'Email',
        'Kategori Issue' => 'Issue Category',
        'Mesej Aduan' => 'Complaint Message',
        'Terangkan isu atau maklum balas anda...' => 'Describe your issue or feedback...',
        'Hantar Aduan' => 'Submit Complaint',
        'Status Aduan Saya' => 'My Complaint Status',
        'Status dikemas kini oleh admin.' => 'Status is updated by an administrator.',
        'Status aduan berjaya dikemas kini.' => 'Complaint status updated successfully.',
        'Personal' => 'Others',
        'Testing' => 'Shopping',
        'Kata laluan baharu mesti sekurang-kurangnya 8 aksara.' => 'The new password must be at least 8 characters long.',
        'Gambar mesti berjaya dimuat naik dan tidak melebihi 2MB.' => 'The image must upload successfully and must not exceed 2MB.',
        'Format gambar yang dibenarkan ialah JPG, PNG atau WebP.' => 'Allowed image formats are JPG, PNG or WebP.',
        'Gambar tidak dapat disimpan.' => 'The image could not be saved.',
        'Profile berjaya dikemas kini.' => 'Profile updated successfully.',
        'Profile tidak dapat dikemas kini.' => 'Profile could not be updated.',
        'Urus gambar dan maklumat akaun anda.' => 'Manage your profile picture and account information.',
        'Pilih avatar' => 'Choose an avatar',
        'Atau upload gambar sendiri' => 'Or upload your own picture',
        'Format JPG, PNG atau WebP. Maksimum 2MB.' => 'JPG, PNG or WebP. Maximum 2MB.',
        'Password baharu' => 'New password',
        'Kosongkan jika tidak mahu tukar' => 'Leave blank to keep your current password',
        'Simpan perubahan' => 'Save changes',
        'Username mesti antara 3 hingga 50 aksara.' => 'Username must be between 3 and 50 characters.',
        'Sila masukkan alamat email yang sah.' => 'Please enter a valid email address.',
        'Username atau email tersebut sudah digunakan.' => 'That username or email is already in use.',
        'Semak URL melalui beberapa sumber threat intelligence.' => 'Check the URL against multiple threat intelligence sources.',
        'Domain biasa akan ditukar kepada HTTPS secara automatik.' => 'A regular domain will automatically use HTTPS.',
        'Imbas fail dengan selamat' => 'Scan files safely',
        'Semak pautan sebelum klik' => 'Check a link before clicking',
        'Scan URL' => 'Scan URL',
        'Scan Link' => 'Scan Link',
        'Scan File' => 'Scan File',
        'Tukar username atau email' => 'Change your username or email',
        'Kami sedia membantu' => 'We are here to help',
        'Hubungi pasukan SecuScan untuk bantuan teknikal, pertanyaan akaun, atau panduan menggunakan sistem.' => 'Contact the SecuScan team for technical support, account questions, or guidance on using the system.',
        'E-mel sokongan' => 'Support email',
        'Waktu operasi' => 'Operating hours',
        'Isnin - Jumaat, 9:00 pagi - 5:00 petang' => 'Monday - Friday, 9:00 AM - 5:00 PM',
        'Perlu laporkan isu?' => 'Need to report an issue?',
        'Hantar butiran isu melalui borang aduan supaya pasukan kami boleh menyiasatnya.' => 'Send the issue details through the complaint form so our team can investigate.',
        'Buka borang aduan' => 'Open complaint form',
        'Hantar aduan atau maklum balas' => 'Submit a complaint or feedback',
        'Bantu kami menjadikan SecuScan lebih baik. Semua medan bertanda diperlukan.' => 'Help us improve SecuScan. All marked fields are required.',
        'Kategori Issue' => 'Issue Category',
        'Mesej Aduan' => 'Complaint Message',
        'Terangkan isu atau maklum balas anda...' => 'Describe your issue or feedback...',
        'Hantar Aduan' => 'Submit Complaint',
        'Status Aduan Saya' => 'My Complaint Status',
        'Status dikemas kini oleh admin.' => 'Status is updated by an administrator.',
    ]);
});
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
if (!empty($_SESSION['is_admin'])) {
    header('Location: admin.php?page=monitoring');
    exit();
}

// --- Threat intelligence integration -------------------------------------
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/services/ScanHandlers.php';

try {
    $conn = secuscan_db();
} catch (Throwable $db_ex) {
    // Never echo the driver message — it leaks host, user and schema name.
    error_log('SecuScan DB error: ' . $db_ex->getMessage());
    http_response_code(503);
    exit('The service is temporarily unavailable. Please try again shortly.');
}

$user_id = (int) ($_SESSION['user_id'] ?? 0);
$username = $_SESSION['username'] ?? 'Guest';
$is_admin = !empty($_SESSION['is_admin']);
$role_label = $is_admin ? 'Admin' : 'User';
$page = $_GET['page'] ?? 'dashboard';
$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar VARCHAR(30) NOT NULL DEFAULT 'avatar-1'");
$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_image VARCHAR(255) NULL");
$conn->query("ALTER TABLE hash_scan_logs ADD COLUMN IF NOT EXISTS tujuan VARCHAR(50) NOT NULL DEFAULT 'Others'");
$conn->query("ALTER TABLE ip_scan_logs ADD COLUMN IF NOT EXISTS tujuan VARCHAR(50) NOT NULL DEFAULT 'Others'");
$allowed_pages = ['dashboard', 'profile', 'scan-link', 'scan-file', 'scan-hash', 'scan-ip', 'threat-map', 'ai-assist', 'news', 'awareness', 'contact', 'complain'];
if (!in_array($page, $allowed_pages, true)) $page = 'dashboard';
if ($is_admin && $page === 'complain') $page = 'dashboard';
$alert_message = '';
$alert_type = 'success';

$avatar_options = [
    'avatar-1' => 'avatars/avatar-user-1.png.jpg',
    'avatar-2' => 'avatars/avatar-user-2.png.jpg',
    'avatar-3' => 'avatars/avatar-user-3.png.jpg',
    'avatar-4' => 'avatars/avatar-user-4.png.jpg',
    'avatar-5' => 'avatars/avatar-user-5.png.jpg',
    'avatar-6' => 'avatars/avatar-user-6.png.jpg',
    'avatar-7' => 'avatars/avatar-user-7.png.jpg',
    'avatar-8' => 'avatars/avatar-user-8.png.jpg',
    'avatar-9' => 'avatars/avatar-user-9.png.jpg',
    'avatar-10' => 'avatars/avatar-user-10.png.jpg',
];

$profile_stmt = $conn->prepare('SELECT username, email, avatar, profile_image FROM users WHERE id = ? LIMIT 1');
$profile_stmt->bind_param('i', $user_id);
$profile_stmt->execute();
$profile_user = $profile_stmt->get_result()->fetch_assoc() ?: [];
$profile_stmt->close();
$profile_avatar = $profile_user['avatar'] ?? 'avatar-1';
$profile_email = $profile_user['email'] ?? '';
$profile_image = $profile_user['profile_image'] ?? '';
$avatar_base_path = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
$profile_image_url = static function ($value) use ($avatar_base_path) {
    $filename = basename((string) $value);
    if ($filename === '') {
        return '';
    }
    return $avatar_base_path . '/uploads/avatars/' . rawurlencode($filename);
};

if (isset($_POST['profile_save'])) {
    $new_username = trim((string) ($_POST['profile_username'] ?? ''));
    $new_email = trim((string) ($_POST['profile_email'] ?? ''));
    $new_password = (string) ($_POST['profile_password'] ?? '');
    $selected_avatar = (string) ($_POST['avatar'] ?? 'avatar-1');
    $selected_avatar = isset($avatar_options[$selected_avatar]) ? $selected_avatar : 'avatar-1';
    $new_image = $profile_image;
    if ($selected_avatar !== $profile_avatar || ($_POST['avatar_selection_changed'] ?? '') === '1') {
        $new_image = '';
    }
    $profile_error = '';

    if ($new_username === '' || strlen($new_username) < 3 || strlen($new_username) > 50) {
        $profile_error = 'Username mesti antara 3 hingga 50 aksara.';
    } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $profile_error = 'Sila masukkan alamat email yang sah.';
    } elseif ($new_password !== '' && strlen($new_password) < 8) {
        $profile_error = 'Password baharu mesti sekurang-kurangnya 8 aksara.';
    } else {
        $duplicate_stmt = $conn->prepare('SELECT id FROM users WHERE (username = ? OR email = ?) AND id <> ? LIMIT 1');
        $duplicate_stmt->bind_param('ssi', $new_username, $new_email, $user_id);
        $duplicate_stmt->execute();
        if ($duplicate_stmt->get_result()->num_rows > 0) $profile_error = 'Username atau email tersebut sudah digunakan.';
        $duplicate_stmt->close();
    }

    if ($profile_error === '' && isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['profile_image']['error'] !== UPLOAD_ERR_OK || $_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
            $profile_error = 'Gambar mesti berjaya dimuat naik dan tidak melebihi 2MB.';
        } else {
            $image_info = @getimagesize($_FILES['profile_image']['tmp_name']);
            $allowed_mimes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            $image_mime = $image_info['mime'] ?? '';
            if (!$image_info || !isset($allowed_mimes[$image_mime])) {
                $profile_error = 'Format gambar yang dibenarkan ialah JPG, PNG atau WebP.';
            } else {
                $avatar_dir = __DIR__ . '/uploads/avatars';
                if (!is_dir($avatar_dir)) mkdir($avatar_dir, 0755, true);
                $new_filename = 'user-' . $user_id . '-' . bin2hex(random_bytes(8)) . '.' . $allowed_mimes[$image_mime];
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $avatar_dir . '/' . $new_filename)) {
                    $new_image = $new_filename;
                } else {
                    $profile_error = 'Gambar tidak dapat disimpan.';
                }
            }
        }
    }

    if ($profile_error === '') {
        $new_password_hash = $new_password !== '' ? password_hash($new_password, PASSWORD_DEFAULT) : null;
        $update_profile = $conn->prepare('UPDATE users SET username = ?, email = ?, password = COALESCE(?, password), avatar = ?, profile_image = ? WHERE id = ?');
        $update_profile->bind_param('sssssi', $new_username, $new_email, $new_password_hash, $selected_avatar, $new_image, $user_id);
        if ($update_profile->execute()) {
            $_SESSION['username'] = $new_username;
            $username = $new_username;
            $profile_email = $new_email;
            $profile_user['email'] = $new_email;
            $profile_avatar = $selected_avatar;
            $profile_image = $new_image;
            $alert_message = 'Profile berjaya dikemas kini.';
        } else {
            $alert_message = 'Profile tidak dapat dikemas kini.';
            $alert_type = 'danger';
        }
        $update_profile->close();
    } else {
        $alert_message = $profile_error;
        $alert_type = 'warning';
    }
    $page = 'profile';
}

// --- Hash and IP scanner handlers ----------------------------------------
// Each returns null when its form was not submitted, so the page stays put.
$hash_scan = handle_hash_scan($user_id);
if ($hash_scan !== null) { $page = 'scan-hash'; }

$file_scan = handle_file_scan($user_id);
if ($file_scan !== null) {
    $page = 'scan-file';
    if ($file_scan['error'] !== '') {
        $alert_message = e($file_scan['error'] ?? '');
        $alert_type = 'warning';
    } else {
        $risk_score = $file_scan['summary']['risk_score'];
        $risk_label = ThreatResult::aggregateLabel($file_scan['summary']['verdict']);
        $alert_message = '<strong>File analysis complete:</strong> Overall assessment <strong>' . e($risk_label) . '</strong>. Risk score: <strong>' . ($risk_score === null ? 'N/A' : (int) $risk_score . '/100') . '</strong>.';
        $alert_type = $file_scan['summary']['verdict'] === ThreatResult::MALICIOUS ? 'danger' : ($file_scan['summary']['verdict'] === ThreatResult::SUSPICIOUS ? 'warning' : 'success');
    }
}

$ip_scan = handle_ip_scan($user_id);
if ($ip_scan !== null) { $page = 'scan-ip'; }

$ai_chat = handle_ai_chat($user_id);
if ($ai_chat !== null) { $page = 'ai-assist'; }

$quiz_result = handle_quiz($user_id);   // null unless the quiz form was submitted
if ($quiz_result !== null) { $page = 'awareness'; }

$map_refresh = handle_threatfox_refresh();
if ($map_refresh !== null) {
    $page = 'threat-map';
    $alert_message = $map_refresh['ok'] ? e($map_refresh['note']) : e($map_refresh['error']);
    $alert_type = $map_refresh['ok'] ? 'success' : 'warning';
}

$url_scan = handle_url_scan($user_id);
$url_report = null;
if ($url_scan !== null) {
    $page = 'scan-link';
    if ($url_scan['error'] !== '') {
        $alert_message = e($url_scan['error']);
        $alert_type = 'warning';
    } else {
        $risk_score = $url_scan['summary']['risk_score'];
        $risk_label = ThreatResult::aggregateLabel($url_scan['summary']['verdict']);
        $alert_message = '<strong>Analysis complete:</strong> Overall assessment <strong>' . e($risk_label) . '</strong>. Risk score: <strong>' . ($risk_score === null ? 'N/A' : (int) $risk_score . '/100') . '</strong>.';
        $alert_type = $url_scan['summary']['verdict'] === ThreatResult::MALICIOUS ? 'danger' : ($url_scan['summary']['verdict'] === ThreatResult::SUSPICIOUS ? 'warning' : 'success');
        $parsed_url = parse_url($url_scan['url']);
        $hostname = (string) ($parsed_url['host'] ?? '');
        $resolved_ip = $hostname !== '' ? gethostbyname($hostname) : '';
        $url_report = [
            'hostname' => $hostname,
            'protocol' => strtoupper((string) ($parsed_url['scheme'] ?? 'HTTPS')),
            'path' => (string) ($parsed_url['path'] ?? '/'),
            'port' => (int) ($parsed_url['port'] ?? (($parsed_url['scheme'] ?? '') === 'http' ? 80 : 443)),
            'ip' => $resolved_ip !== $hostname ? $resolved_ip : 'Not Available',
            'risk_score' => $risk_score,
        ];
    }
}

if (isset($_POST['complaint_btn'])) {
    $complaint_name = trim($_POST['complaint_name'] ?? '');
    $complaint_email = trim($_POST['complaint_email'] ?? '');
    $complaint_category = trim($_POST['complaint_category'] ?? 'Other');
    $complaint_message = trim($_POST['complaint_message'] ?? '');
    if ($complaint_name !== '' && filter_var($complaint_email, FILTER_VALIDATE_EMAIL) && $complaint_message !== '') {
        $stmt = mysqli_prepare($conn, 'INSERT INTO complaints (user_id, name, email, category, message) VALUES (?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'issss', $user_id, $complaint_name, $complaint_email, $complaint_category, $complaint_message);
        if (mysqli_stmt_execute($stmt)) {
            $alert_message = 'Your complaint was submitted successfully. Thank you for helping improve SecuScan.';
        } else {
            $alert_message = 'The complaint could not be saved. Make sure the complaints table has been created.';
            $alert_type = 'danger';
        }
        mysqli_stmt_close($stmt);
    } else {
        $alert_message = 'Please provide your name, a valid email address, and a complaint message.';
        $alert_type = 'warning';
    }
    $page = 'complain';
}

if ($is_admin && isset($_POST['update_complaint_status'])) {
    $complaint_id = (int) ($_POST['complaint_id'] ?? 0);
    $status = $_POST['status'] ?? 'New';
    if ($complaint_id > 0 && in_array($status, ['New', 'In Progress', 'Resolved'], true)) {
        $status_stmt = mysqli_prepare($conn, 'UPDATE complaints SET status = ? WHERE id = ?');
        mysqli_stmt_bind_param($status_stmt, 'si', $status, $complaint_id);
        mysqli_stmt_execute($status_stmt);
        mysqli_stmt_close($status_stmt);
        $alert_message = 'Status aduan berjaya dikemas kini.';
    }
    $page = 'dashboard';
}

// ---------------------------------------------------------------------------
// Dashboard figures.
//
// Four scan types now feed this, not two. Hash and IP scans were being written
// to their own tables and counted nowhere, so the dashboard read zero even
// after a successful scan.
//
// Everything below is a prepared statement. The old string-concatenated
// `' WHERE user_id = ' . $user_id` worked only because of the int cast above —
// one careless edit away from an injection.
// ---------------------------------------------------------------------------

/** Run a counting query, optionally scoped to one user. */
function count_rows(mysqli $conn, string $sql, bool $scoped, int $userId): int
{
    if ($scoped) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $userId);
    } else {
        $stmt = $conn->prepare(str_replace(['WHERE user_id = ?', 'AND user_id = ?'], ['WHERE 1', 'AND 1'], $sql));
    }
    $stmt->execute();
    $total = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
    $stmt->close();
    return $total;
}

function verdict_is_threat(string $value): bool
{
    $normalized = strtolower(trim((string) $value));
    if ($normalized === '') return false;
    $terms = ['phishing', 'malware', 'malicious', 'suspicious', 'danger', 'unsafe', 'high risk'];
    foreach ($terms as $term) {
        if (str_contains($normalized, $term)) return true;
    }
    return false;
}

function verdict_is_safe(string $value): bool
{
    $normalized = strtolower(trim((string) $value));
    if ($normalized === '') return false;
    if (verdict_is_threat($value)) return false;
    $terms = ['clean', 'safe', 'benign', 'not detected', 'no threat'];
    foreach ($terms as $term) {
        if (str_contains($normalized, $term)) return true;
    }
    return false;
}

function history_result_class(string $result): string
{
    $normalized = strtolower(trim($result));
    if (verdict_is_threat($result)) return 'text-bg-danger';
    if (str_contains($normalized, 'suspicious')) return 'text-bg-warning';
    if (verdict_is_safe($result)) return 'text-bg-success';
    return 'text-bg-secondary';
}

$scoped = !$is_admin;

$total_scanned =
      count_rows($conn, 'SELECT COUNT(*) AS total FROM scan_logs WHERE user_id = ?', $scoped, $user_id)
    + count_rows($conn, 'SELECT COUNT(*) AS total FROM file_scan_logs WHERE user_id = ?', $scoped, $user_id)
    + count_rows($conn, 'SELECT COUNT(*) AS total FROM hash_scan_logs WHERE user_id = ?', $scoped, $user_id)
    + count_rows($conn, 'SELECT COUNT(*) AS total FROM ip_scan_logs WHERE user_id = ?', $scoped, $user_id);

// For hash and IP scans "threat" means the verdict enum said so. Suspicious
// counts as a threat here: a partial signal still deserves the student's
// attention on a dashboard tile.
$total_threats =
      count_rows($conn, "SELECT COUNT(*) AS total FROM scan_logs WHERE LOWER(hasil_pemeriksaan) REGEXP 'phishing|malware|malicious|suspicious|danger|unsafe|high risk' AND user_id = ?", $scoped, $user_id)
    + count_rows($conn, "SELECT COUNT(*) AS total FROM file_scan_logs WHERE LOWER(hasil_pemeriksaan) REGEXP 'phishing|malware|malicious|suspicious|danger|unsafe|high risk' AND user_id = ?", $scoped, $user_id)
    + count_rows($conn, "SELECT COUNT(*) AS total FROM hash_scan_logs WHERE LOWER(verdict) REGEXP 'malicious|suspicious|danger|unsafe|high risk' AND user_id = ?", $scoped, $user_id)
    + count_rows($conn, "SELECT COUNT(*) AS total FROM ip_scan_logs WHERE LOWER(verdict) REGEXP 'malicious|suspicious|danger|unsafe|high risk' AND user_id = ?", $scoped, $user_id);

$total_safe =
      count_rows($conn, "SELECT COUNT(*) AS total FROM scan_logs WHERE LOWER(hasil_pemeriksaan) REGEXP 'clean|safe|benign|not detected|no threat' AND user_id = ?", $scoped, $user_id)
    + count_rows($conn, "SELECT COUNT(*) AS total FROM file_scan_logs WHERE LOWER(hasil_pemeriksaan) REGEXP 'clean|safe|benign|not detected|no threat' AND user_id = ?", $scoped, $user_id)
    + count_rows($conn, "SELECT COUNT(*) AS total FROM hash_scan_logs WHERE LOWER(verdict) REGEXP 'clean|safe|benign|not detected|no threat' AND user_id = ?", $scoped, $user_id)
    + count_rows($conn, "SELECT COUNT(*) AS total FROM ip_scan_logs WHERE LOWER(verdict) REGEXP 'clean|safe|benign|not detected|no threat' AND user_id = ?", $scoped, $user_id);

$total_inconclusive = max(0, $total_scanned - $total_threats - $total_safe);

/** Fetch recent rows from one table, normalised into a common shape. */
function recent_scans(mysqli $conn, string $sql, bool $scoped, int $userId, callable $map): array
{
    if ($scoped) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $userId);
    } else {
        $stmt = $conn->prepare(str_replace('WHERE user_id = ?', 'WHERE 1', $sql));
    }
    $stmt->execute();
    $res = $stmt->get_result();
    $out = [];
    while ($row = $res->fetch_assoc()) { $out[] = $map($row); }
    $stmt->close();
    return $out;
}

$history = array_merge(
    recent_scans($conn, 'SELECT * FROM scan_logs WHERE user_id = ? ORDER BY id DESC LIMIT 8', $scoped, $user_id,
        fn($r) => ['kind' => 'URL', 'icon' => 'fa-link', 'tone' => 'text-primary',
                   'item' => $r['url'], 'result' => $r['hasil_pemeriksaan'],
                   'result_class' => history_result_class((string) $r['hasil_pemeriksaan']),
                   'bad' => in_array(strtolower(trim((string) $r['hasil_pemeriksaan'])), ['malicious', 'suspicious', 'phishing', 'malware'], true),
                   'time' => $r['tarikh_semak']]),
    recent_scans($conn, 'SELECT * FROM file_scan_logs WHERE user_id = ? ORDER BY id DESC LIMIT 8', $scoped, $user_id,
        fn($r) => ['kind' => 'File', 'icon' => 'fa-file', 'tone' => 'text-warning',
                   'item' => $r['filename'], 'result' => $r['hasil_pemeriksaan'],
                   'result_class' => history_result_class((string) $r['hasil_pemeriksaan']),
                   'bad' => in_array(strtolower(trim((string) $r['hasil_pemeriksaan'])), ['malicious', 'suspicious', 'phishing', 'malware'], true),
                   'time' => $r['tarikh_semak']]),
    recent_scans($conn, 'SELECT * FROM hash_scan_logs WHERE user_id = ? ORDER BY id DESC LIMIT 8', $scoped, $user_id,
        fn($r) => ['kind' => 'Hash', 'icon' => 'fa-fingerprint', 'tone' => 'text-info',
                   'item' => ($r['filename'] !== '' ? $r['filename'] . ' · ' : '') . substr($r['file_hash'], 0, 16) . '…',
                   'result' => ucfirst($r['verdict']),
                   'result_class' => history_result_class((string) $r['verdict']),
                   'bad' => in_array(strtolower((string) $r['verdict']), ['malicious', 'suspicious'], true),
                   'time' => $r['scanned_at']]),
    recent_scans($conn, 'SELECT * FROM ip_scan_logs WHERE user_id = ? ORDER BY id DESC LIMIT 8', $scoped, $user_id,
        fn($r) => ['kind' => 'IP', 'icon' => 'fa-globe', 'tone' => 'text-success',
                   'item' => $r['ip_address'] . ($r['country_code'] !== '' ? ' (' . $r['country_code'] . ')' : ''),
                   'result' => ucfirst($r['verdict']),
                   'result_class' => history_result_class((string) $r['verdict']),
                   'bad' => in_array(strtolower((string) $r['verdict']), ['malicious', 'suspicious'], true),
                   'time' => $r['scanned_at']])
);
foreach ($history as &$history_row) {
    if (!isset($history_row['result_class'])) {
        $history_row['result_class'] = history_result_class((string) ($history_row['result'] ?? ''));
    }
}
unset($history_row);
usort($history, static fn($a, $b) => strcmp((string) $b['time'], (string) $a['time']));
$history = array_slice($history, 0, 8);
$user_complaints = mysqli_query($conn, 'SELECT * FROM complaints WHERE user_id = ' . $user_id . ' ORDER BY created_at DESC');
$admin_complaints = null;
$admin_new_complaints = 0;
if ($is_admin) {
    $admin_complaints = mysqli_query($conn, "SELECT c.*, u.username FROM complaints c LEFT JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC LIMIT 8");
    $admin_new_complaints = (int) (mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM complaints WHERE status = 'New'"))['total'] ?? 0);
}

$menu = [
    'dashboard' => ['Dashboard', 'fa-chart-line'], 'scan-link' => ['Scan Link', 'fa-link'],
    'scan-file' => ['Scan File', 'fa-file-shield'],
    'scan-hash' => ['Hash Scanner', 'fa-fingerprint'],
    'scan-ip'   => ['IP Scanner', 'fa-globe'],
    'threat-map' => ['Threat Map', 'fa-earth-asia'],
    'ai-assist' => ['AI Assist', 'fa-robot'],
    'news'      => ['Cybersecurity News', 'fa-newspaper'],
    'awareness' => ['Cybersecurity Info & Awareness', 'fa-lightbulb'],
    'contact' => ['Contact Us', 'fa-headset'], 'complain' => ['Complain & Feedback', 'fa-message'],
];
if ($is_admin) unset($menu['complain']);
function e($value) { return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html lang="ms"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>SecuScan | <?php echo e($menu[$page][0]); ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet"><link href="style.css?v=20260915" rel="stylesheet">
<style>
:root{--ink:#172033;--muted:#718096;--blue:#2563eb;--pale:#f6f8fc}body{background:var(--pale);color:var(--ink)}.app-shell{min-height:100vh;display:flex}.sidebar{width:272px;background:#fff;border-right:1px solid #e9eef5;padding:28px 18px;position:fixed;inset:0 auto 0 0;z-index:10}.brand{font-size:1.35rem;font-weight:800;color:var(--ink);letter-spacing:-.03em;padding:0 14px 30px}.brand i{color:var(--blue)}.nav-label{color:#a0aec0;font-size:.68rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;padding:0 14px;margin:18px 0 8px}.side-link{display:flex;align-items:center;gap:13px;color:#718096;font-weight:600;font-size:.88rem;padding:12px 14px;border-radius:12px;text-decoration:none;margin:3px 0}.side-link i{width:18px;text-align:center}.side-link:hover,.side-link.active{color:var(--blue);background:#eff5ff}.main{margin-left:272px;width:calc(100% - 272px);padding:28px 42px 48px}.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:32px}.eyebrow{color:var(--blue);font-weight:800;font-size:.72rem;text-transform:uppercase;letter-spacing:.1em}.page-title{font-size:1.75rem;font-weight:800;letter-spacing:-.04em;margin:4px 0}.clean-card{background:#fff;border:1px solid #e7edf5;border-radius:18px;box-shadow:0 8px 24px rgba(30,55,90,.045)}.stat-card{padding:22px;height:100%}.stat-icon{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:#eff5ff;color:var(--blue)}.stat-value{font-size:2rem;font-weight:800;margin-top:16px}.stat-name{color:var(--muted);font-size:.78rem;font-weight:700}.section-title{font-size:1.05rem;font-weight:800}.form-control,.form-select{border-color:#dfe6ef;border-radius:11px;padding:.78rem .9rem}.form-control:focus,.form-select:focus{border-color:#8db3ff;box-shadow:0 0 0 .2rem rgba(37,99,235,.1)}.btn-primary{background:var(--blue);border-color:var(--blue);border-radius:10px;padding:.7rem 1.1rem;font-weight:700}.mini-bar{height:9px;background:#edf2f7;border-radius:10px;overflow:hidden}.mini-bar span{display:block;height:100%;background:var(--blue);border-radius:10px}.info-banner{background:linear-gradient(110deg,#14213d,#2563eb);color:#fff;border-radius:18px;padding:30px}.table th{color:#8a97a8;font-size:.7rem;text-transform:uppercase;letter-spacing:.06em;border-bottom-color:#edf1f6}.table td{vertical-align:middle;font-size:.85rem}
@media(max-width:900px){.sidebar{width:76px;padding:20px 10px}.brand{font-size:0;text-align:center;padding:0 0 25px}.brand i{font-size:1.4rem}.nav-label,.side-link span{display:none}.side-link{justify-content:center;padding:13px}.main{margin-left:76px;width:calc(100% - 76px);padding:22px 18px}}@media(max-width:575px){.topbar{align-items:flex-start;gap:10px}.user-pill small{display:none}.page-title{font-size:1.4rem}}
</style><style>
</style><style>
body{background:linear-gradient(135deg,#f8fbff 0%,#eef4ff 42%,#f1f5f9 100%)!important;color:#0f172a!important}.app-shell:before{background:rgba(96,165,250,.25)!important;opacity:.6!important}.app-shell:after{background:rgba(147,197,253,.25)!important;opacity:.6!important}.sidebar{background:rgba(255,255,255,.88)!important;border-right:1px solid rgba(148,163,184,.18)!important;box-shadow:16px 0 40px rgba(15,23,42,.05)}.brand{color:#0f172a!important}.nav-label{color:#64748b!important}.side-link{color:#475569!important}.side-link:hover,.side-link.active{color:#2563eb!important;background:linear-gradient(90deg,rgba(37,99,235,.08),rgba(59,130,246,.04))!important;box-shadow:inset 3px 0 #60a5fa,0 0 14px rgba(37,99,235,.06)}.eyebrow{color:#2563eb!important}.page-title{color:#0f172a!important;text-shadow:none}.user-pill strong{color:#0f172a}.user-pill small{color:#64748b!important}.clean-card,.stat-card{background:rgba(255,255,255,.96)!important;border-color:#e2e8f0!important;box-shadow:0 18px 42px rgba(15,23,42,.06),inset 0 1px rgba(255,255,255,.9)!important}.clean-card:hover,.stat-card:hover{border-color:rgba(96,165,250,.32)!important;box-shadow:0 22px 52px rgba(30,41,59,.08),0 0 16px rgba(96,165,250,.08)!important}.stat-name,.text-muted{color:#64748b!important}.stat-value{color:#0f172a}.stat-icon{background:rgba(37,99,235,.08)!important;box-shadow:none}.section-title{color:#0f172a}.table{--bs-table-color:#334155;--bs-table-hover-color:#0f172a;--bs-table-hover-bg:rgba(59,130,246,.04);--bs-table-bg:transparent}.table th{color:#64748b!important;border-bottom-color:rgba(148,163,184,.22)!important}.table td{border-bottom-color:rgba(148,163,184,.18)!important}.form-control,.form-select{background:#fff!important;color:#0f172a!important;border-color:#cbd5e1!important}.form-control::placeholder{color:#94a3b8!important}.btn-outline-primary{color:#2563eb;border-color:#93c5fd}.btn-outline-primary:hover{color:#fff;background:#2563eb}.btn-light{background:#fff!important;color:#0f172a!important;border-color:#dbeafe!important}.btn-light:hover{background:#f8fafc!important;color:#0f172a!important}.info-banner{background:linear-gradient(135deg,rgba(191,219,254,.8),rgba(224,231,255,.9))!important;border:1px solid rgba(147,197,253,.5)!important;color:#0f172a!important;padding:1.5rem;border-radius:1rem}.alert{border-radius:1rem!important}.alert-success{background:rgba(34,197,94,.08)!important;color:#166534!important;border-color:rgba(34,197,94,.18)!important}.alert-warning{background:rgba(245,158,11,.08)!important;color:#92400e!important;border-color:rgba(245,158,11,.18)!important}.alert-danger{background:rgba(239,68,68,.08)!important;color:#991b1b!important;border-color:rgba(239,68,68,.18)!important}.text-bg-success{background-color:#22c55e!important}.text-bg-danger{background-color:#ef4444!important}.text-bg-primary{background-color:#2563eb!important}.badge{border:1px solid rgba(148,163,184,.2)}.btn-close{filter:none}
</style><style>
#scan-loading{position:fixed;inset:0;z-index:2000;display:flex;align-items:center;justify-content:center;background:rgba(239,246,255,.72);backdrop-filter:blur(8px);opacity:0;visibility:hidden;pointer-events:none;transition:opacity .2s ease,visibility .2s ease}
#scan-loading.is-visible{opacity:1;visibility:visible;pointer-events:auto}
.scan-loader{position:relative;width:min(90vw,420px);padding:42px 28px 34px;text-align:center;overflow:hidden;border:1px solid rgba(37,99,235,.25);border-radius:18px;background:linear-gradient(145deg,rgba(255,255,255,.97),rgba(236,245,255,.96));box-shadow:0 20px 50px rgba(37,99,235,.14),inset 0 0 30px rgba(37,99,235,.04)}
.scan-loader:before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,transparent 0%,rgba(96,165,250,.12) 48%,rgba(96,165,250,.25) 50%,rgba(96,165,250,.12) 52%,transparent 100%);transform:translateY(-100%);animation:scan-laser 2.2s ease-in-out infinite;pointer-events:none}
.scan-loader:after{content:"";position:absolute;inset:12px;border:1px solid rgba(37,99,235,.12);border-radius:12px;pointer-events:none}
.scan-loader-icon{position:relative;z-index:1;display:grid;place-items:center;width:84px;height:84px;margin:0 auto 22px;border:1px solid rgba(37,99,235,.55);border-radius:50%;color:#2563eb;font-size:2.35rem;box-shadow:0 0 0 8px rgba(37,99,235,.06),0 0 24px rgba(96,165,250,.18);animation:cyber-pulse 1.6s ease-in-out infinite;background:rgba(255,255,255,.7)}
.scan-loader-icon:before{content:"";position:absolute;inset:9px;border:1px dashed rgba(37,99,235,.5);border-radius:50%;animation:radar-spin 2.8s linear infinite}
.scan-loader-title,.scan-loader-status{position:relative;z-index:1}
.scan-loader-title{margin:0;color:#0f172a;font-size:1.1rem;font-weight:700;letter-spacing:.02em}
.scan-loader-status{height:24px;margin:12px 0 0;color:#2563eb;font-size:.85rem;letter-spacing:.03em;animation:status-cycle 6s steps(1,end) infinite}
.scan-loader-status span{display:block;opacity:0;animation:status-message 6s infinite}
.scan-loader-status span:nth-child(2){animation-delay:2s}.scan-loader-status span:nth-child(3){animation-delay:4s}
@keyframes scan-laser{0%{transform:translateY(-100%)}55%,100%{transform:translateY(100%)}}
@keyframes cyber-pulse{0%,100%{transform:scale(.96);box-shadow:0 0 0 8px rgba(37,99,235,.05),0 0 18px rgba(96,165,250,.16)}50%{transform:scale(1.04);box-shadow:0 0 0 15px rgba(37,99,235,.02),0 0 28px rgba(96,165,250,.30)}}
@keyframes radar-spin{to{transform:rotate(360deg)}}
@keyframes status-message{0%,28%{opacity:1}33%,100%{opacity:0}}
@media(prefers-reduced-motion:reduce){.scan-loader:before,.scan-loader-icon,.scan-loader-icon:before,.scan-loader-status span{animation:none}.scan-loader-status span:first-child{opacity:1}}
</style><style>
.profile-avatar{width:46px;height:46px;display:grid;place-items:center;overflow:hidden;flex-shrink:0;border-radius:50%;background:#eff6ff;border:1px solid #dbeafe}.profile-avatar img{display:block;width:100%;height:100%;max-width:100%;object-fit:cover}.profile-avatar-sm{width:42px;height:42px}.profile-layout{display:grid;grid-template-columns:minmax(280px,.85fr) minmax(0,1.15fr);gap:24px;align-items:stretch}.profile-hero{min-height:390px;display:flex;flex-direction:column;justify-content:flex-end;overflow:hidden;padding:0;position:relative;background:linear-gradient(145deg,#e0edff,#f8fbff)}.profile-hero-image{width:min(100%,390px);aspect-ratio:1/1;margin:34px auto 0;overflow:hidden;border:8px solid rgba(255,255,255,.82);border-radius:50%;box-shadow:0 22px 50px rgba(30,64,175,.14);background:#dbeafe}.profile-hero-image img{display:block;width:100%;height:100%;max-width:100%;object-fit:cover}.profile-hero-copy{padding:22px 28px 28px;background:rgba(255,255,255,.72)}.profile-hero-copy h2{margin:4px 0 0;font-size:clamp(1.5rem,3vw,2.2rem);font-weight:800;color:#0f172a}.profile-role{display:inline-flex;align-items:center;padding:6px 11px;color:#2563eb;background:#eff6ff;border:1px solid #dbeafe;border-radius:999px;font-size:.78rem;font-weight:700}.profile-editor{padding:30px}.profile-editor-heading{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;margin-bottom:28px}.avatar-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:12px}.avatar-choice{cursor:pointer}.avatar-choice input{position:absolute;opacity:0;pointer-events:none}.avatar-choice .profile-avatar{width:52px;height:52px;transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease}.avatar-choice input:checked+.profile-avatar{border-color:#2563eb;box-shadow:0 0 0 4px rgba(37,99,235,.14)}
@media(max-width:900px){.profile-layout{grid-template-columns:1fr}.profile-hero{min-height:auto}.profile-hero-image{width:min(62vw,300px)}}
@media(max-width:575px){.profile-editor{padding:22px}.profile-hero-copy{padding:18px 22px 22px}.avatar-grid{gap:8px}.avatar-choice .profile-avatar{width:44px;height:44px}}
</style></head><body><div id="scan-loading" aria-hidden="true" role="status" aria-live="polite"><div class="scan-loader"><div class="scan-loader-icon"><i class="fa-solid fa-shield-halved"></i></div><p class="scan-loader-title">SecuScan threat analysis in progress</p><div class="scan-loader-status"><span>Analyzing URL Threat Level...</span><span>Checking Heuristic Patterns...</span><span>Verifying Domain Safety...</span></div></div></div><div class="app-shell">
<aside class="sidebar"><a class="brand text-decoration-none" href="index.php?page=dashboard"><i class="fa-solid fa-shield-halved me-2"></i>SecuScan</a><div class="nav-label">Workspace</div>
<?php foreach ($menu as $key => $item): ?><a class="side-link <?php echo $page === $key ? 'active' : ''; ?>" href="index.php?page=<?php echo e($key); ?>"><i class="fa-solid <?php echo e($item[1]); ?>"></i><span><?php echo e($item[0]); ?></span></a><?php endforeach; ?><div class="nav-label">Account</div><?php if ($is_admin): ?><a class="side-link" href="admin.php"><i class="fa-solid fa-user-gear"></i><span>Admin Panel</span></a><?php endif; ?><a class="side-link" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i><span>Log out</span></a></aside>
<main class="main"><header class="topbar"><div><div class="eyebrow">SecuScan security centre</div><h1 class="page-title"><?php echo e($menu[$page][0] ?? 'Profile'); ?></h1><div class="typing-line"><span id="typing-text"></span></div></div><a class="user-pill d-flex align-items-center gap-2 text-decoration-none" href="index.php?page=profile"><div class="profile-avatar profile-avatar-sm"><?php if ($profile_image): ?><img src="<?php echo e($profile_image_url($profile_image)); ?>" alt="Profile avatar"><?php else: ?><img src="<?php echo e($avatar_options[$profile_avatar] ?? $avatar_options['avatar-1']); ?>" alt="Profile avatar"><?php endif; ?></div><div><strong><?php echo e($username); ?></strong><small class="d-block text-muted"><?php echo e($role_label); ?></small></div></a></header>
<?php if ($alert_message): ?><div class="alert alert-<?php echo e($alert_type); ?> alert-dismissible fade show rounded-4" role="alert"><i class="fa-solid fa-circle-info me-2"></i><?php echo $alert_message; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?><?php if ($page === 'scan-link' && !empty($url_scan)): ?><?php include __DIR__ . '/pages/url-scan-report.php'; ?><?php endif; ?><?php if ($page === 'scan-file' && !empty($file_scan)): ?><?php include __DIR__ . '/pages/file-scan-result.php'; ?><?php endif; ?>
<?php if ($page === 'dashboard'): ?><div class="row g-3 mb-4"><?php foreach ([['Total Scanned',$total_scanned,'fa-magnifying-glass','text-primary'],['Threat Detected',$total_threats,'fa-triangle-exclamation','text-danger'],['Safe Logs',$total_safe,'fa-shield-heart','text-success']] as $stat): ?><div class="col-md-4"><div class="clean-card stat-card"><div class="d-flex justify-content-between"><span class="stat-name"><?php echo e($stat[0]); ?></span><span class="stat-icon <?php echo e($stat[3]); ?>"><i class="fa-solid <?php echo e($stat[2]); ?>"></i></span></div><div class="stat-value counter-ready" data-target="<?php echo (int) $stat[1]; ?>">0</div><small class="text-muted"><?php echo $is_admin?'All users':'Your account'; ?></small></div></div><?php endforeach; ?></div>
<div class="row g-4 mb-4"><div class="col-lg-7"><div class="clean-card p-4 h-100"><div class="d-flex justify-content-between mb-4"><div><div class="section-title">Ringkasan keselamatan</div><small class="text-muted">Nisbah rekod bersih berbanding ancaman</small></div><i class="fa-solid fa-chart-simple text-primary fs-4"></i></div><div class="mb-4"><div class="d-flex justify-content-between small mb-2"><span>Safe logs</span><strong><?php echo $total_scanned?round($total_safe/$total_scanned*100):0; ?>%</strong></div><div class="mini-bar"><span style="width:<?php echo $total_scanned?round($total_safe/$total_scanned*100):0; ?>%"></span></div></div><div class="mb-4"><div class="d-flex justify-content-between small mb-2"><span>Threat detected</span><strong><?php echo $total_scanned?round($total_threats/$total_scanned*100):0; ?>%</strong></div><div class="mini-bar"><span style="width:<?php echo $total_scanned?round($total_threats/$total_scanned*100):0; ?>%;background:#ef4444"></span></div></div>
<div><div class="d-flex justify-content-between small mb-2"><span>Inconclusive</span><strong><?php echo $total_scanned?round($total_inconclusive/$total_scanned*100):0; ?>%</strong></div><div class="mini-bar"><span style="width:<?php echo $total_scanned?round($total_inconclusive/$total_scanned*100):0; ?>%;background:#94a3b8"></span></div><small class="text-muted d-block mt-2" style="font-size:.75rem">Not seen by any provider, or the lookup failed. Neither safe nor flagged.</small></div></div></div><div class="col-lg-5"><div class="info-banner h-100"><i class="fa-solid fa-lock fa-2x mb-4"></i><h3 class="h5 fw-bold">Stay one step ahead.</h3><p class="small opacity-75">Semak pautan meragukan dan hash fail sebelum berkongsi atau membukanya.</p><a href="index.php?page=scan-link" class="btn btn-light btn-sm fw-bold">Mula Scan <i class="fa-solid fa-arrow-right ms-1"></i></a></div></div></div>
<div class="clean-card p-4"><div class="d-flex justify-content-between align-items-center mb-3"><div><div class="section-title">Sejarah scan terkini</div><small class="text-muted">8 rekod paling baharu</small></div><a href="index.php?page=scan-link" class="btn btn-sm btn-outline-primary">Scan baharu</a></div><div class="table-responsive"><table class="table table-hover"><thead><tr><th>Jenis</th><th>Item</th><th>Keputusan</th><th>Masa</th></tr></thead><tbody><?php foreach ($history as $row): ?><tr><td class="<?php echo e($row['tone']); ?>"><i class="fa-solid <?php echo e($row['icon']); ?> me-2"></i><?php echo e($row['kind']); ?></td><td class="text-break"><?php echo e($row['item']); ?></td><td><span class="badge <?php echo $row['bad']?'text-bg-danger':'text-bg-success'; ?> rounded-pill"><?php echo e($row['result']); ?></span></td><td class="text-muted"><?php echo e($row['time']); ?></td></tr><?php endforeach; if(empty($history)): ?><tr><td colspan="4" class="text-center text-muted py-4">Belum ada rekod scan.</td></tr><?php endif; ?></tbody></table></div></div>
<?php if ($is_admin): ?><div class="clean-card p-4 mt-4"><div class="d-flex justify-content-between align-items-center mb-3"><div><div class="section-title"><i class="fa-solid fa-inbox me-2 text-primary"></i>Aduan pengguna</div><small class="text-muted">Admin boleh mengurus aduan terus dari dashboard ini.</small></div><span class="badge text-bg-danger rounded-pill"><?php echo $admin_new_complaints; ?> baharu</span></div><div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th>Pengguna</th><th>Kategori</th><th>Mesej</th><th>Status</th><th>Tarikh</th></tr></thead><tbody><?php if ($admin_complaints && mysqli_num_rows($admin_complaints) > 0): while ($complaint = mysqli_fetch_assoc($admin_complaints)): ?><tr><td><strong><?php echo e($complaint['name']); ?></strong><small class="d-block text-muted"><?php echo e($complaint['email']); ?></small></td><td><?php echo e($complaint['category']); ?></td><td class="text-muted" style="max-width:280px"><?php echo e($complaint['message']); ?></td><td><form method="post" class="d-flex gap-1"><input type="hidden" name="complaint_id" value="<?php echo (int) $complaint['id']; ?>"><select name="status" class="form-select form-select-sm"><option <?php echo $complaint['status'] === 'New' ? 'selected' : ''; ?>>New</option><option <?php echo $complaint['status'] === 'In Progress' ? 'selected' : ''; ?>>In Progress</option><option <?php echo $complaint['status'] === 'Resolved' ? 'selected' : ''; ?>>Resolved</option></select><button name="update_complaint_status" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-check"></i></button></form></td><td><small class="text-muted"><?php echo e($complaint['created_at']); ?></small></td></tr><?php endwhile; else: ?><tr><td colspan="5" class="text-center text-muted py-3">Belum ada aduan.</td></tr><?php endif; ?></tbody></table></div></div><?php endif; ?>
<?php elseif ($page === 'scan-link' || $page === 'scan-file'): ?><div class="clean-card p-4 p-lg-5" style="max-width:850px"><div class="mb-4"><span class="stat-icon mb-3"><i class="fa-solid <?php echo $page==='scan-link'?'fa-link':'fa-file-shield'; ?>"></i></span><h2 class="h4 fw-bold"><?php echo $page==='scan-link'?'Semak pautan sebelum klik':'Imbas fail dengan selamat'; ?></h2><p class="text-muted mb-0"><?php echo $page==='scan-link'?'Semak URL melalui beberapa sumber threat intelligence.':'SecuScan hanya menghantar hash SHA-256 kepada enjin semakan, bukan kandungan fail mentah.'; ?></p></div><?php if($page==='scan-link'): ?><form method="post"><label class="form-label fw-semibold">Tujuan Semakan</label><select name="tujuan" class="form-select mb-3" required><option value="">-- Pilih tujuan --</option><option value="Education">Pelajaran / Education</option><option value="Work">Kerja / Work</option><option value="Personal">Semakan Peribadi / Personal Check</option><option value="Testing">Pengujian / Testing</option></select><label class="form-label fw-semibold">Domain atau URL yang ingin disemak</label><div class="input-group"><input type="text" name="url_input" class="form-control" placeholder="example.com atau https://example.com" required><button class="btn btn-primary" name="scan_url_btn"><i class="fa-solid fa-radar me-2"></i>Scan Link</button></div><small class="text-muted d-block mt-2">Domain biasa akan ditukar kepada HTTPS secara automatik.</small></form><?php if ($url_scan && $url_scan['error'] === ''): ?><div class="url-result-card mt-4"><div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3"><div><small class="text-muted d-block">Decision for</small><strong class="text-break"><?php echo e($url_scan['url']); ?></strong></div><span class="badge <?php echo $url_scan['summary']['verdict'] === ThreatResult::MALICIOUS ? 'text-bg-danger' : ($url_scan['summary']['verdict'] === ThreatResult::SUSPICIOUS ? 'text-bg-warning' : ($url_scan['summary']['verdict'] === ThreatResult::CLEAN ? 'text-bg-success' : 'text-bg-secondary')); ?> rounded-pill px-3 py-2"><?php echo e(ThreatResult::aggregateLabel($url_scan['summary']['verdict'])); ?></span></div><div class="provider-result-grid"><?php foreach ($url_scan['results'] as $provider_result): ?><div class="provider-result"><div class="d-flex justify-content-between align-items-center gap-2"><strong><?php echo e($provider_result->displayName()); ?></strong><span class="badge <?php echo e($provider_result->badgeClass()); ?> rounded-pill"><?php echo e($provider_result->label()); ?></span></div><small class="text-muted d-block mt-2"><?php echo e($provider_result->summary); ?></small></div><?php endforeach; ?></div></div><?php endif; ?><?php else: ?><form method="post" enctype="multipart/form-data"><label class="form-label fw-semibold">Tujuan Semakan</label><select name="tujuan" class="form-select mb-3" required><option value="">-- Pilih tujuan --</option><option value="Education">Pelajaran / Education</option><option value="Work">Kerja / Work</option><option value="Personal">Semakan Peribadi / Personal Check</option><option value="Testing">Pengujian / Testing</option></select><label class="form-label fw-semibold">Pilih fail</label><input type="file" name="file_input" class="form-control mb-3" required><button class="btn btn-primary" name="scan_file_btn"><i class="fa-solid fa-shield-virus me-2"></i>Scan File</button></form><?php endif; ?></div>
<?php elseif ($page === 'profile'): ?><div class="profile-layout"><section class="profile-hero clean-card"><div class="profile-hero-image"><?php if ($profile_image): ?><img src="<?php echo e($profile_image_url($profile_image)); ?>" alt="Profile picture"><?php else: ?><img src="<?php echo e($avatar_options[$profile_avatar] ?? $avatar_options['avatar-1']); ?>" alt="Profile avatar"><?php endif; ?></div><div class="profile-hero-copy"><div class="eyebrow">SecuScan profile</div><h2><?php echo e($username); ?></h2><p class="text-muted mb-3"><?php echo e($profile_user['email'] ?? ''); ?></p><span class="profile-role"><i class="fa-solid fa-shield-halved me-1"></i><?php echo e($role_label); ?></span></div></section><section class="clean-card profile-editor"><div class="profile-editor-heading"><div><h2 class="h4 fw-bold mb-1">Edit profile</h2><p class="text-muted mb-0">Urus gambar dan maklumat akaun anda.</p></div><i class="fa-solid fa-user-pen text-primary fs-3"></i></div><form method="post" enctype="multipart/form-data"><label class="form-label fw-semibold">Username</label><input type="text" name="profile_username" class="form-control mb-4" value="<?php echo e($username); ?>" minlength="3" maxlength="50" required><label class="form-label fw-semibold">Pilih avatar</label><div class="avatar-grid mb-4"><?php foreach ($avatar_options as $avatar_key => $avatar_url): ?><label class="avatar-choice"><input type="radio" name="avatar" value="<?php echo e($avatar_key); ?>" <?php echo $profile_avatar === $avatar_key ? 'checked' : ''; ?>><span class="profile-avatar"><img src="<?php echo e($avatar_url); ?>" alt="<?php echo e($avatar_key); ?>"></span></label><?php endforeach; ?></div><label class="form-label fw-semibold">Atau upload gambar sendiri</label><input type="file" name="profile_image" class="form-control mb-1" accept="image/jpeg,image/png,image/webp"><small class="text-muted d-block mb-4">Format JPG, PNG atau WebP. Maksimum 2MB.</small><label class="form-label fw-semibold">Password baharu <span class="text-muted fw-normal">(optional)</span></label><input type="password" name="profile_password" class="form-control mb-4" minlength="8" autocomplete="new-password" placeholder="Kosongkan jika tidak mahu tukar"><button type="submit" name="profile_save" class="btn btn-primary"><i class="fa-solid fa-floppy-disk me-2"></i>Simpan perubahan</button></form></section></div>
<?php elseif ($page === 'awareness'): ?><?php include __DIR__ . '/pages/awareness.php'; ?>
<?php elseif ($page === 'contact'): ?><div class="row g-4"><div class="col-lg-7"><div class="clean-card p-4 p-lg-5"><h2 class="h4 fw-bold">Kami sedia membantu</h2><p class="text-muted">Hubungi pasukan SecuScan untuk bantuan teknikal, pertanyaan akaun, atau panduan menggunakan sistem.</p><div class="d-flex gap-3 align-items-center border-top pt-3 mt-4"><i class="fa-solid fa-envelope text-primary fs-4"></i><div><small class="text-muted d-block">E-mel sokongan</small><strong>support@secuscan.com</strong></div></div><div class="d-flex gap-3 align-items-center border-top pt-3 mt-3"><i class="fa-solid fa-clock text-primary fs-4"></i><div><small class="text-muted d-block">Waktu operasi</small><strong>Isnin - Jumaat, 9:00 pagi - 5:00 petang</strong></div></div></div></div><div class="col-lg-5"><div class="clean-card p-4 h-100"><i class="fa-solid fa-circle-question text-primary fs-3 mb-3"></i><h3 class="h5 fw-bold">Perlu laporkan isu?</h3><p class="small text-muted">Hantar butiran isu melalui borang aduan supaya pasukan kami boleh menyiasatnya.</p><a href="index.php?page=complain" class="btn btn-primary">Buka borang aduan</a></div></div></div>
<?php elseif ($page === 'scan-hash'): ?><?php include __DIR__ . '/pages/scan-hash.php'; ?>
<?php elseif ($page === 'scan-ip'): ?><?php include __DIR__ . '/pages/scan-ip.php'; ?>
<?php elseif ($page === 'threat-map'): ?><?php include __DIR__ . '/pages/threat-map.php'; ?>
<?php elseif ($page === 'ai-assist'): ?><?php include __DIR__ . '/pages/ai-assist.php'; ?>
<?php elseif ($page === 'news'): ?><?php include __DIR__ . '/pages/news.php'; ?>
<?php else: ?><div class="clean-card p-4 p-lg-5 mb-4" style="max-width:800px"><h2 class="h4 fw-bold mb-2">Hantar aduan atau maklum balas</h2><p class="text-muted mb-4">Bantu kami menjadikan SecuScan lebih baik. Semua medan bertanda diperlukan.</p><form method="post"><div class="row g-3"><div class="col-md-6"><label class="form-label fw-semibold">Nama</label><input name="complaint_name" class="form-control" value="<?php echo e($username==='Guest'?'':$username); ?>" required></div><div class="col-md-6"><label class="form-label fw-semibold">E-mel</label><input type="email" name="complaint_email" class="form-control" required></div><div class="col-12"><label class="form-label fw-semibold">Kategori Issue</label><select name="complaint_category" class="form-select"><option>Technical Issue</option><option>Scan Result</option><option>Account & Access</option><option>Suggestion</option><option>Other</option></select></div><div class="col-12"><label class="form-label fw-semibold">Mesej Aduan</label><textarea name="complaint_message" class="form-control" rows="6" placeholder="Terangkan isu atau maklum balas anda..." required></textarea></div><div class="col-12"><button class="btn btn-primary" name="complaint_btn"><i class="fa-solid fa-paper-plane me-2"></i>Hantar Aduan</button></div></div></form></div><div class="clean-card p-4" style="max-width:800px"><div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="h5 fw-bold mb-1"><i class="fa-solid fa-clock-rotate-left text-primary me-2"></i>Status Aduan Saya</h2><small class="text-muted">Status dikemas kini oleh admin.</small></div></div><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Kategori</th><th>Mesej</th><th>Status</th><th>Tarikh</th></tr></thead><tbody><?php if ($user_complaints && mysqli_num_rows($user_complaints) > 0): while ($complaint = mysqli_fetch_assoc($user_complaints)): ?><tr><td><?php echo e($complaint['category']); ?></td><td class="text-muted" style="max-width:300px"><?php echo e($complaint['message']); ?></td><td><?php $status_class = $complaint['status'] === 'Resolved' ? 'text-bg-success' : ($complaint['status'] === 'In Progress' ? 'text-bg-warning' : 'text-bg-danger'); ?><span class="badge <?php echo $status_class; ?> rounded-pill"><?php echo e($complaint['status']); ?></span></td><td><small class="text-muted"><?php echo e($complaint['created_at']); ?></small></td></tr><?php endwhile; else: ?><tr><td colspan="4" class="text-center text-muted py-3">Anda belum menghantar sebarang aduan.</td></tr><?php endif; ?></tbody></table></div></div><?php endif; ?></main></div><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><script>
document.addEventListener('DOMContentLoaded', function () {
    var scanLayoutStyle = document.createElement('style');
    scanLayoutStyle.textContent = '.scan-split{display:grid;grid-template-columns:minmax(0,5fr) minmax(0,7fr);gap:24px;align-items:stretch}.scan-split>.clean-card,.scan-split>.security-report{height:100%;margin-bottom:0}.scan-split>.security-report{min-width:0}.scan-empty-panel{min-height:420px;padding:40px 28px;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}.scan-split .security-report{padding:28px}@media(max-width:900px){.scan-split{grid-template-columns:1fr}.scan-empty-panel{min-height:260px}}';
    document.head.appendChild(scanLayoutStyle);
    var scanFormCard = document.querySelector('main > .clean-card[style*="max-width:850px"]');
    var scanReport = document.querySelector('main > .security-report');
    if (scanFormCard) {
        var scanSplit = document.createElement('div');
        scanSplit.className = 'scan-split';
        scanFormCard.parentNode.insertBefore(scanSplit, scanFormCard);
        scanSplit.appendChild(scanFormCard);
        if (scanReport) {
            scanSplit.appendChild(scanReport);
            var inlineUrlResult = scanFormCard.querySelector('.url-result-card');
            if (inlineUrlResult) inlineUrlResult.remove();
        } else {
            var emptyScanPanel = document.createElement('div');
            emptyScanPanel.className = 'clean-card scan-empty-panel';
            emptyScanPanel.innerHTML = '<i class="fa-solid fa-shield-halved fs-1 text-primary opacity-50 mb-3"></i><h3 class="h5 fw-bold">No scan yet</h3><p class="text-muted mb-0">Submit a scan to see the full security report here.</p>';
            scanSplit.appendChild(emptyScanPanel);
        }
    }
    var profileUsername = document.querySelector('[name="profile_username"]');
    var avatarGrid = document.querySelector('.avatar-grid');
    if (profileUsername && avatarGrid && !document.querySelector('[name="profile_email"]')) {
        avatarGrid.previousElementSibling.insertAdjacentHTML('beforebegin', '<label class="form-label fw-semibold">Email</label><input type="email" name="profile_email" class="form-control mb-4" value="<?php echo e($profile_email); ?>" required>');
    }
    if (avatarGrid) {
        var profileForm = avatarGrid.closest('form');
        var avatarChanged = document.createElement('input');
        avatarChanged.type = 'hidden';
        avatarChanged.name = 'avatar_selection_changed';
        avatarChanged.value = '0';
        profileForm.appendChild(avatarChanged);
        avatarGrid.querySelectorAll('input[name="avatar"]').forEach(function (avatarInput) {
            avatarInput.addEventListener('change', function () {
                avatarChanged.value = '1';
                var selectedImage = avatarInput.parentElement.querySelector('img');
                var heroImage = document.querySelector('.profile-hero-image img');
                var headerImage = document.querySelector('.profile-avatar-sm img');
                if (selectedImage && heroImage) heroImage.src = selectedImage.src;
                if (selectedImage && headerImage) headerImage.src = selectedImage.src;
            });
        });
    }
    document.querySelectorAll('.table tbody .badge').forEach(function (badge) {
        var result = (badge.textContent || '').trim().toLowerCase();
        badge.classList.remove('text-bg-danger', 'text-bg-warning', 'text-bg-success', 'text-bg-secondary');
        if (result === 'malicious' || result === 'phishing' || result === 'malware') badge.classList.add('text-bg-danger');
        else if (result === 'suspicious') badge.classList.add('text-bg-warning');
        else if (result === 'safe' || result === 'clean') badge.classList.add('text-bg-success');
        else badge.classList.add('text-bg-secondary');
    });
    var typingTarget = document.getElementById('typing-text');
    var typingText = 'AI-Powered Security Engine...';
    var typingIndex = 0;
    function typeNext() { if (!typingTarget) return; typingTarget.textContent = typingText.slice(0, typingIndex++); if (typingIndex <= typingText.length) window.setTimeout(typeNext, 65); }
    typeNext();

    document.querySelectorAll('.counter-ready').forEach(function (counter) {
        var target = Number(counter.dataset.target || 0);
        var start = performance.now();
        function count(now) { var progress = Math.min((now - start) / 850, 1); counter.textContent = Math.floor(progress * target).toLocaleString(); if (progress < 1) requestAnimationFrame(count); }
        requestAnimationFrame(count);
    });

    var loading = document.getElementById('scan-loading');
    document.querySelectorAll('form').forEach(function (form) {
        if (form.querySelector('[name="scan_url_btn"], [name="scan_file_btn"]')) form.addEventListener('submit', function () { if (loading) { loading.classList.add('is-visible'); loading.setAttribute('aria-hidden', 'false'); } });
    });
});
</script></body></html>